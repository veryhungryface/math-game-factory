import bpy, math, json, os, random
from mathutils import Vector
ROOT=os.environ.get('ORBIT_PROJECT_ROOT',os.path.join(os.path.dirname(os.path.abspath(__file__)),'generated-project'))
ASSET=ROOT+'/public/g/orbit-courier/assets'
OUT=ROOT+'/scratchpad/exports/orbit-courier'
os.makedirs(ASSET,exist_ok=True);os.makedirs(OUT,exist_ok=True)
scene=bpy.data.scenes.new('Orbit Courier • Asset Studio');bpy.context.window.scene=scene

def mat(name,c,metal=0,rough=.35,emit=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if emit:p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=emit
 return m
ivory=mat('OC | warm porcelain',(.91,.86,.71),.15)
red=mat('OC | vermilion enamel',(.65,.065,.04),.28,.26)
brass=mat('OC | champagne brass',(.62,.38,.12),.65,.28)
navy=mat('OC | midnight graphite',(.025,.048,.063),.35)
glass=mat('OC | sapphire ceramic',(.018,.30,.49),.5,.17)
cyan=mat('OC | cyan energy',(.025,.7,.86),.25,.22,1.4)
moonmat=mat('OC | blue moon stone',(.38,.52,.60),.08,.75)
rockmat=mat('OC | iron meteorite',(.21,.24,.28),.22,.68)
flame=mat('OC | warm exhaust',(.99,.32,.025),.1,.32,2)
white=mat('OC | star ivory',(.83,.92,1),0,.5,2)
assets={};current=[]
def finish(o,name,m,smooth=True,bevel=0):
 o.name=name;o.data.materials.append(m)
 if o.type=='MESH':
  for p in o.data.polygons:p.use_smooth=smooth
  if bevel:
   b=o.modifiers.new('Soft edges','BEVEL');b.width=bevel;b.segments=2
   bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=b.name)
 current.append(o);return o

def lathe(name,profile,m,n=32):
 v=[(r*math.cos(2*math.pi*j/n),r*math.sin(2*math.pi*j/n),z) for z,r in profile for j in range(n)]
 f=[(i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j) for i in range(len(profile)-1) for j in range(n)]
 f+=[tuple(reversed(range(n))),tuple((len(profile)-1)*n+j for j in range(n))]
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(v,[],f);mesh.update();o=bpy.data.objects.new(name,mesh);scene.collection.objects.link(o);return finish(o,name,m)
def torus(name,r,t,loc,m,rot=(0,0,0),n=40,k=8):
 bpy.ops.mesh.primitive_torus_add(major_segments=n,minor_segments=k,major_radius=r,minor_radius=t,location=loc,rotation=rot);return finish(bpy.context.object,name,m)
def cyl(name,r,d,loc,m,n=40,bevel=0):
 bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=d,location=loc);return finish(bpy.context.object,name,m,True,bevel)
def ico(name,r,loc,m,sub=2,scale=None,smooth=False):
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub,radius=r,location=loc);o=bpy.context.object
 if scale:o.scale=scale
 return finish(o,name,m,smooth)
def cube(name,loc,scale,m,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,m,False,bevel)
def close_asset(name,shift=(0,0,0)):
 global current
 groups={}
 for o in current:
  if o.type=='FONT':
   bpy.context.view_layer.objects.active=o;bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.ops.object.convert(target='MESH')
  o.location+=Vector(shift)
  groups.setdefault(o.data.materials[0].name,[]).append(o)
 merged=[]
 for mn,objs in groups.items():
  bpy.ops.object.select_all(action='DESELECT')
  for o in objs:o.select_set(True)
  bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.join();o=bpy.context.object;scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');o.name=name+' | '+mn.split('|')[-1].strip();merged.append(o)
 bpy.ops.object.select_all(action='DESELECT')
 for o in merged:o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=ASSET+'/'+name+'.glb',export_format='GLB',use_selection=True,use_active_scene=True,export_yup=True,export_animations=False,export_cameras=False,export_lights=False)
 assets[name]=merged;current=[]

# Preserve the exact silhouette/palette of the user's original rocket, rebuilt at a game budget.
lathe('Pressure hull',[(1.15,.45),(1.24,.56),(1.50,.70),(1.90,.78),(2.40,.82),(3.35,.82),(3.92,.78),(4.32,.68),(4.50,.61)],ivory,40)
lathe('Red nose',[(4.48,.615),(4.62,.60),(4.86,.53),(5.10,.43),(5.32,.32),(5.52,.20),(5.67,.10),(5.74,.03),(5.755,.001)],red,40)
torus('Nose seam',.613,.035,(0,0,4.49),brass)
torus('Lower hull trim',.729,.046,(0,0,1.66),red)
lathe('Bell engine',[(.75,.46),(.82,.49),(1.00,.39),(1.22,.29),(1.31,.34)],navy)
torus('Engine rim',.47,.045,(0,0,.78),brass)
outline=[(.57,2.50),(.91,2.26),(1.43,1.39),(1.53,.51),(1.34,.48),(.87,1.00),(.57,1.25)]
for i in range(3):
 a=math.radians(30+120*i);v=[(r*math.cos(a)-t*math.sin(a),r*math.sin(a)+t*math.cos(a),z) for t in [-.105,.105] for r,z in outline];n=len(outline);f=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(j,(j+1)%n,(j+1)%n+n,j+n) for j in range(n)];me=bpy.data.meshes.new('fin');me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new('Swept fin',me);scene.collection.objects.link(o);finish(o,o.name,red,False,.045)
torus('Porthole frame',.335,.063,(0,-.796,3.56),brass,(math.pi/2,0,0))
torus('Window seal',.285,.021,(0,-.847,3.56),navy,(math.pi/2,0,0))
bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,location=(0,-.83,3.56));o=bpy.context.object;o.scale=(.286,.095,.286);finish(o,'Sapphire porthole',glass)
for i in range(8):
 a=2*math.pi*i/8;ico('Window rivet',.023,(.338*math.cos(a),-.858,3.56+.338*math.sin(a)),navy,1,smooth=True)
cu=bpy.data.curves.new('Mission ID','FONT');cu.body='01';cu.align_x='CENTER';cu.size=.37;cu.extrude=.001;cu.resolution_u=3;o=bpy.data.objects.new('Mission 01',cu);scene.collection.objects.link(o);o.location=(0,-.826,2.69);o.rotation_euler=(math.pi/2,0,0);finish(o,o.name,red)
close_asset('rocket',(0,0,-3.10))

# Real depressed craters and raised lips in one opaque mesh.
random.seed(301)
bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=5,radius=1);o=bpy.context.object
craters=[(Vector(v).normalized(),r) for v,r in [((.35,-1,.35),.24),((-.5,-1,.2),.18),((.0,-1,-.45),.15),((.7,-.55,-.15),.12),((-.3,-.3,.9),.20),((1,.1,.3),.22),((-.8,.5,.2),.20),((.1,1,.3),.26),((-.6,-.7,-.5),.10)]]
for v in o.data.vertices:
 d=v.co.normalized();h=1+random.uniform(-.004,.004)
 for p,r in craters:
  a=math.acos(max(-1,min(1,d.dot(p))));q=a/r
  if q<1:h-=.065*(1-q*q)**2
  if abs(q-1)<.25:h+=.018*(1-abs(q-1)/.25)
 v.co=d*h
finish(o,'Cratered moon',moonmat,True);close_asset('moon')

# A compact landing outpost with inset pad, docking arms, observation dome and beacon.
cyl('Floating platform',1.70,.20,(0,0,.10),navy,48,.045)
cyl('Porcelain rim',1.65,.10,(0,0,.225),ivory,48,.025)
cyl('Landing inset',1.36,.05,(-.18,-.12,.298),navy,48)
torus('Landing guidance circle',1.12,.025,(-.18,-.12,.335),cyan,n=48)
torus('Outer brass lip',1.58,.025,(0,0,.285),brass,n=48)
for dx in [-.32,.32]:cube('Landing H leg',(dx-.18,-.18,.345),(.09,.8,.018),ivory)
cube('Landing H crossbar',(-.18,-.18,.345),(.72,.09,.02),ivory)
cyl('Habitat collar',.43,.14,(.91,.55,.37),brass,32,.03)
cyl('Observation tower',.36,1.2,(.91,.55,1.01),ivory,32,.03)
cyl('Tower glass band',.38,.27,(.91,.55,1.35),glass,32)
torus('Top brass ring',.38,.025,(.91,.55,1.50),brass,n=32)
ico('Observation dome',.39,(.91,.55,1.56),ivory,3,scale=(1,1,.62),smooth=True)
cyl('Beacon antenna',.025,.5,(.91,.55,2.0),brass,12)
ico('Navigation beacon',.095,(.91,.55,2.30),cyan,2,smooth=True)
for a in [0,math.pi*2/3,math.pi*4/3]:
 x,y=1.45*math.cos(a),1.45*math.sin(a);cyl('Guide post',.035,.25,(x,y,.425),brass,12);ico('Guide light',.065,(x,y,.58),cyan,1,smooth=True)
for dx in [-1,1]:
 cube('Solar wing strut',(.91+dx*.62,.55,1.04),(1.1,.08,.08),brass,.01)
 cube('Solar wing',(.91+dx*.83,.55,1.04),(.62,.64,.055),glass,.02)
 for j in [-1,0,1]:cube('Solar wing grid',(.91+dx*.83,.55+j*.19,1.074),(.59,.012,.008),brass)
close_asset('station')

random.seed(92);o=ico('Meteorite',1,(0,0,0),rockmat,2)
for v in o.data.vertices:v.co*=random.uniform(.81,1.12)
o.scale=(1.05,.87,.93);close_asset('asteroid')
lathe('Luminous energy vessel',[(-.52,.10),(-.46,.19),(-.34,.23),(.34,.23),(.46,.19),(.52,.10)],cyan,20)
for z in [-.46,.46]:cyl('Brass capsule end',.22,.12,(0,0,z),brass,20,.018)
for a in [0,2*math.pi/3,4*math.pi/3]:
 o=cube('Brass energy brace',(.22*math.cos(a),.22*math.sin(a),0),(.035,.035,.80),brass,.006)
close_asset('energy')

# Frozen metadata before arranging display copies.
manifest={'provenance':'Original models authored in Blender 5.2 via Blender MCP. Rocket is a game-optimized reconstruction of the user-created rocket-test.blend silhouette and materials. No third-party geometry or external textures.','axis':'glTF +Y up; rocket nose +Y, window +Z.','assets':{}}
for name,objs in assets.items():
 pts=[o.matrix_world@Vector(v) for o in objs for v in o.bound_box];lo=[min(p[i] for p in pts) for i in range(3)];hi=[max(p[i] for p in pts) for i in range(3)];tris=0
 for o in objs:o.data.calc_loop_triangles();tris+=len(o.data.loop_triangles)
 manifest['assets'][name]={'file':name+'.glb','bytes':os.path.getsize(ASSET+'/'+name+'.glb'),'triangles':tris,'drawCalls':len(objs),'gltfBounds':{'min':[lo[0],lo[2],-hi[1]],'max':[hi[0],hi[2],-lo[1]]}}
with open(ASSET+'/manifest.json','w') as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
# Put originals into a hidden collection and use linked geometry in the hero scene.
orig=bpy.data.collections.new('EXPORT ORIGINALS • origin aligned');scene.collection.children.link(orig)
for objs in assets.values():
 for o in objs:
  for c in list(o.users_collection):c.objects.unlink(o)
  orig.objects.link(o);o.hide_render=True;o.hide_set(True)
def show(name,pos,scale=1,rot=(0,0,0)):
 holder=bpy.data.objects.new('DISPLAY '+name,None);scene.collection.objects.link(holder);holder.location=pos;holder.scale=(scale,scale,scale);holder.rotation_euler=rot
 for src in assets[name]:
  o=src.copy();o.data=src.data;scene.collection.objects.link(o);o.hide_render=False;o.hide_set(False);o.parent=holder;o.location=(0,0,0)
 return holder
show('rocket',(-1.35,-.6,1.25),.90,(math.radians(-10),math.radians(22),math.radians(-8)))
show('moon',(2.15,1.0,-.35),2.55)
show('station',(1.9,-.1,2.03),.67,(0,0,math.radians(-15)))
for pos,s in [((-3.5,1.4,-1.5),.33),((4.8,1.5,2.4),.35),((.2,2.4,3.7),.2)]:show('asteroid',pos,s,(.4,.5,.7))
for pos in [(-2.0,-.5,-1.2),(-2.65,-.15,-.6),(-3.0,.3,.1)]:show('energy',pos,.38,(.2,.4,.3))
# Small flame tucked under rocket, only in cover; game controls its own thruster.
current=[];lathe('Cover exhaust',[(-2.2,.005),(-1.75,.12),(-1.40,.18),(-1.25,.17)],flame,24)
for o in current:o.location=(-1.92,-.35,.5);o.rotation_euler=(math.radians(-10),math.radians(22),math.radians(-8))
current=[]
world=bpy.data.worlds.new('Orbit midnight');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.009,.019,.036,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5
# Sculptural orbit rings and sparse stars anchor the space composition.
torus('Orbital flight path',3.90,.016,(1.3,1.1,-.10),brass,(.18,.23,0),n=160,k=6)
random.seed(118)
for i in range(78):
 x=random.uniform(-8,8);z=random.uniform(-5,7);ico('Distant star',random.choice([.009,.014,.022]),(x,5,z),white,1)

def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
def light(name,pos,power,color,size):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.color=color;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=pos;aim(o,(0,0,1))
light('Large warm key',(-5,-7,10),1700,(1,.82,.64),7)
light('Polar cyan rim',(4,4,7),2200,(.34,.72,1),5)
light('Soft front fill',(5,-7,2),1050,(.67,.83,1),6)
d=bpy.data.cameras.new('Orbit Courier Cover');cam=bpy.data.objects.new('Orbit Courier Cover',d);scene.collection.objects.link(cam);cam.location=(9,-19,11);aim(cam,(.2,.35,1.0));d.type='ORTHO';d.ortho_scale=12.3;scene.camera=cam
scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=True;scene.render.resolution_x=1200;scene.render.resolution_y=630;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.filepath=ROOT+'/public/g/orbit-courier/thumb.png';scene.view_settings.view_transform='AgX'
scene.render.film_transparent=False
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/orbit-courier-assets.blend')
print(json.dumps(manifest,ensure_ascii=False))

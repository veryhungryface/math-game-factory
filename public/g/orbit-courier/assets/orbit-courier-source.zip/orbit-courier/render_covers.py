import bpy, os
ROOT=os.path.dirname(os.path.abspath(__file__))
scene=bpy.data.scenes['Orbit Courier • Asset Studio']
bpy.context.window.scene=scene
scene.render.resolution_x=1200;scene.render.resolution_y=630;scene.render.filepath=ROOT+'/thumb.png'
bpy.ops.render.render(write_still=True,scene=scene.name)
scene.render.resolution_x=1080;scene.render.resolution_y=1080;scene.camera.data.ortho_scale=10.3;scene.render.filepath=ROOT+'/square.png'
bpy.ops.render.render(write_still=True,scene=scene.name)

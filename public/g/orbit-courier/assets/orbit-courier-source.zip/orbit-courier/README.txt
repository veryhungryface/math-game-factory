별빛 항로 — Blender 게임 에셋

Blender에서 orbit-courier-assets.blend를 열면 로켓과 달 기지 장면을 바로 볼 수 있습니다.
EXPORT ORIGINALS 컬렉션에는 원점에 정렬한 원본 게임 모델이 있습니다.
DISPLAY 오브젝트들은 표지 장면의 배치용 복사본입니다.
기존 rocket-test.blend는 수정하지 않았습니다.

assets/*.glb: 브라우저 게임에 쓰는 실제 모델 5종. 외부 텍스처 없음.
thumb.png: 1200 × 630 / square.png: 1080 × 1080
assets/manifest.json: 모델별 크기·삼각형·드로콜·좌표 범위.

좌표: glTF +Y 위. 로켓 코 +Y, 창문 +Z. 로켓 중심 원점, 높이 5.268.
달과 운석은 반지름 약 1. 기지는 바닥이 Y=0. 에너지 통 높이 1.04.

생성 코드: generate_assets.py를 Blender 스크립팅 탭에서 실행.
기본 출력은 스크립트 옆 generated-project/ 폴더이며 ORBIT_PROJECT_ROOT 환경 변수로 변경할 수 있습니다.
모든 모델은 Blender에서 직접 제작. 로켓은 앞서 만든 로켓의 실루엣과 팔레트를 게임용으로 최적화했습니다.

런타임 보조 코드: assets/lib/의 JavaScript 2종은 Three.js 0.185.1(r185)의 원본 복사본입니다.
이 두 파일은 직접 제작한 모델과 별개인 MIT 라이선스 오픈소스이며, 라이선스 전문은 assets/lib/LICENSE에 포함했습니다.

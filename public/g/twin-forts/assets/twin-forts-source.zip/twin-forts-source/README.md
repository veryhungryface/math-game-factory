# 쌍둥이 요새 — original model source

Seven original low-poly Blender models used by the actual Three.js game, plus the exact cover-scene source and the procedural generator. No downloaded models, textures, or Supercell artwork are included.

## Open the source

Open `twin-forts-assets.blend` in Blender 5.2 or later. The visible tabletop is the cover scene. The `Original export meshes` collection contains the origin-aligned source models; those export meshes are hidden for the cover render. Enable their viewport visibility to inspect or edit them. Each model is merged by material for inexpensive game rendering. Cover text was converted to meshes so opening the blend requires no external fonts or textures.

## Regenerate models and both covers

```sh
blender --background --python generate_assets.py -- --output-dir ./generated-game --source-dir ./regenerated-source --font-path /path/to/a/Korean-font.ttf
```

The font is only needed for Korean cover text. On macOS, the script defaults to the system Apple SD Gothic Neo font. No system font is distributed in this archive. Use any legally available Korean font on other systems. No Python packages besides Blender's own Python API are required.

The generator writes GLBs and `manifest.json` under the output directory's `assets/`, and renders `thumb.png` (1200×630) and `square.png` (1080×1080). A completed Blender source scene is written to the source directory. It creates a fresh background scene and never overwrites a user's open Blender session. Rendered source text is converted to meshes when saving the portable blend.

## Game model contract

- glTF +Y is up; +Z is forward; all assets rest on y=0.
- Robot: 0.76 wide × 0.51 deep × 1.039 high. 572 triangles, two primitives.
- Fort: 2.10 wide × 2.00 deep × 2.445 high. 908 triangles, two primitives.
- Home keep: 3.00 wide × 2.70 deep × 3.54 high. 776 triangles, two primitives.
- Tree: 64 triangles; rock: 20 triangles; banner: 92 triangles.
- `TOY_BODY_VERTEX_COLOR` uses glTF `COLOR_0`. Preserve vertex colors.
- `TEAM_BLUE`, `TEAM_CORAL`, and `TEAM_TEAL` may be recolored for teams.
- No armatures or animation tracks. The game moves, bounces and flashes cloned roots.

## Provenance

Models: project-original geometry made from Blender primitives, beveled boxes and custom roof/flag vertices. Authoring tool: Blender 5.2.1 LTS, background CLI. No external textures. Cover images are original Cycles renders of these same models, not unrelated concept art.

Campaign key art: generated separately using the built-in OpenAI image-generation tool on 2026-09-07, one generation, no source image or third-party art supplied. The exact prompt is in `imagegen-prompt.txt`. The runtime game uses that locally saved key art on its title screen. It is not included in this source archive because the archive focuses on editable geometry; it remains in the game's assets/title-keyart.png.

Cost record: Blender is local; no model-service charge. Built-in image generation was used, no separately billed API/CLI fallback was invoked. This tool did not expose a monetary charge, so no exact image-generation cost is claimed.

The public game's local GLTFLoader utility helpers retain their upstream three.js MIT license separately in assets/lib/LICENSE. They are not needed to regenerate these Blender assets.

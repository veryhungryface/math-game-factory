# 쌍둥이 요새 — sculpted battle models, revision 2

This archive contains the actual seven revised game GLBs, the editable Blender scene and its complete procedural generator. These replace the first version's simple box soldiers and roofed houses with original armored machines and gun forts. No Supercell geometry, artwork, logos, characters or downloaded textures are present.

## Source and regeneration

Open `twin-forts-assets.blend` in Blender 5.2 or newer. The tabletop is the cover scene. The hidden `Original export meshes` collection holds the seven game assets at the origin. Cover lettering is converted to meshes so opening this file requires no external fonts or textures.

```sh
blender --background --python generate_assets.py -- --output-dir ./generated-game --source-dir ./regenerated-source --font-path /path/to/a/Korean-font.ttf
```

On macOS, the font argument defaults to the installed Apple SD Gothic Neo system font. Other platforms can supply a legally available Korean font. No system font file is redistributed. The generator only uses Blender's bundled Python modules. Run it in a background Blender process; it creates a fresh scene and does not affect an open interactive Blender session.

Output: `assets/*.glb`, `assets/manifest.json`, 1200×630 `thumb.png`, 1080×1080 `square.png`, and a portable source blend in the chosen source directory.

## Mesh contract

- glTF +Y up, +Z forward, all assets resting at y=0. Authoring is Blender +Z up, -Y forward.
- `TOY_BODY_VERTEX_COLOR` and `ARMOR_METAL_VERTEX_COLOR` both use `COLOR_0` and must retain vertex colors.
- Recolor only `TEAM_BLUE`, `TEAM_CORAL` or `TEAM_TEAL` for team variants.
- No rig or animation tracks. Animate cloned roots in the game.
- Trooper: 1644 triangles, 3 primitives. 1.16 wide × 0.73 deep × 1.25 high. Rounded dome helmet, separate pauldrons/gauntlets/boots, small bright optical slit, enamel shield with metal rim.
- Fort: 4796 triangles, 3 primitives. 2.48 wide × 2.16 deep × 2.538 high. Thick stone plinth, circular side bastions, stone parapets, inset wooden gate and a cannon with an actual recessed bore.
- Home keep: 5868 triangles, 3 primitives. 3.32 wide × 2.74 deep × 3.585 high. Large fortified blockhouse, twin guns and command beacon.
- Tree: rounded overlapping crowns, a modeled trunk and spreading roots. 1656 triangles, 1 primitive.
- Rock: 100 triangles, 1 primitive. Banner: 664 triangles, 3 primitives.
- Dimensions and counts are also recorded in the machine-readable manifest. All seven GLBs together are below 0.61 MB.

## Provenance and validation

Created locally in Blender 5.2.1 LTS using custom lathe profiles, polygon shields, beveled primitives and weighted/smooth normals. Broad forms and materials were revised after visually comparing the supplied battle-arena reference; that reference was not copied into any asset. Two-segment bevels and separate rough/metal materials replace the previous uniformly flat shading.

The covers are Cycles renders of these exact models. They are not generated substitute illustrations. Individual unit/fort studio renders are provided separately in the project scratchpad for visual inspection. GLB structure, triangle counts, `COLOR_0`, ground alignment, cover dimensions and ZIP CRC were checked.

The older `title-keyart.png` in the game assets was created during revision 1 with the built-in OpenAI image tool. It is a separate illustration and is not the source of the revised meshes. This revision makes no new image-generation or API calls. All modeling and rendering run locally; no model-service charge is incurred. Any prior built-in image-generation dollar charge was not exposed by the tool and is not claimed.

The runtime's upstream Three.js utility files retain their existing MIT license in assets/lib/LICENSE. They are not needed by this Blender generator.

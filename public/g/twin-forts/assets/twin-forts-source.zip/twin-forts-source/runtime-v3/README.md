# Runtime scenery, revision 3

The Blender file and seven GLB models retain their revision-2 geometry.
Revision 3 adds original Three.js bank stones, wood/iron bridge details, low foliage,
curved water glints and daylight/grass-surface tuning at runtime.
Copy environment.mjs beside game.js. Serve with the existing repository's local
Three.js import map and revision-2 assets. No CDN or new external assets are used.
Math, input, score, saves and game-state rules are unchanged.
Cover renders continue to depict the same revision-2 models; they were not re-rendered.

import bpy, math, json, os, random, argparse
from mathutils import Vector
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'../..'))
parser=argparse.ArgumentParser();parser.add_argument('--output-dir',default=os.path.join(ROOT,'public/g/twin-forts'));parser.add_argument('--source-dir',default=os.path.dirname(__file__));parser.add_argument('--font-path',default='/System/Library/Fonts/AppleSDGothicNeo.ttc');args=parser.parse_args(__import__('sys').argv[__import__('sys').argv.index('--')+1:] if '--' in __import__('sys').argv else [])
GAME=os.path.abspath(args.output_dir);ASSET=os.path.join(GAME,'assets');OUT=os.path.abspath(args.source_dir);os.makedirs(OUT,exist_ok=True)
os.makedirs(ASSET,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene
scene.name='Twin Forts original toy workshop'
current=[]; assets={}
# All original geometry, a shared vertex-colour material keeps each robot at two draw calls.
def material(name,color):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=.57;return m
body=material('TOY_BODY_VERTEX_COLOR',(1,1,1));p=body.node_tree.nodes.get('Principled BSDF');a=body.node_tree.nodes.new('ShaderNodeVertexColor');a.layer_name='Color';body.node_tree.links.new(a.outputs['Color'],p.inputs['Base Color'])
blue=material('TEAM_BLUE',(.022,.36,.60));coral=material('TEAM_CORAL',(.95,.19,.095));teal=material('TEAM_TEAL',(.015,.47,.41))
C={'ivory':(.91,.80,.53),'light':(1,.91,.69),'dark':(.018,.042,.052),'sand':(.60,.38,.16),'stone':(.35,.47,.38),'gold':(1,.59,.08),'trunk':(.27,.13,.06),'leaf':(.27,.59,.045),'leaf2':(.46,.75,.09),'grass':(.13,.43,.15),'side':(.30,.26,.11),'water':(.025,.48,.52),'path':(.84,.64,.33)}
def finish(o,name,col='ivory',team=None,bevel=0):
 o.name=name
 if bevel:
  b=o.modifiers.new('Chunky single bevel','BEVEL');b.width=bevel;b.segments=1
  bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=b.name)
 if team:o.data.materials.append(team)
 else:
  o.data.materials.append(body);ca=o.data.color_attributes.new(name='Color',type='FLOAT_COLOR',domain='CORNER');c=C.get(col,col)
  for d in ca.data:d.color=(*c,1)
 for poly in o.data.polygons:poly.use_smooth=False
 current.append(o);return o

def cube(name,loc,dims,col='ivory',team=None,b=.03):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.scale=dims;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,col,team,b)
def cyl(name,loc,r,d,col='ivory',team=None,n=8,rot=None,b=0):
 bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=d,location=loc,rotation=rot or (0,0,0));return finish(bpy.context.object,name,col,team,b)
def ico(name,loc,scale,col='leaf',sub=1):
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub,radius=1,location=loc);o=bpy.context.object;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,col)
def roof(name,loc,w,d,h,team):
 v=[(-w/2,-d/2,0),(w/2,-d/2,0),(w/2,d/2,0),(-w/2,d/2,0),(-w*.22,-d*.22,h),(w*.22,-d*.22,h),(w*.22,d*.22,h),(-w*.22,d*.22,h)]
 f=[(3,2,1,0),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)]
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);o.location=loc;return finish(o,name,team=team,bevel=.028)
def close(name):
 global current
 groups={}
 for o in current:groups.setdefault(o.data.materials[0].name,[]).append(o)
 merged=[]
 for key,objs in groups.items():
  bpy.ops.object.select_all(action='DESELECT')
  for o in objs:o.select_set(True)
  bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.join();o=bpy.context.object;scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');o.name=name+'_'+key;merged.append(o)
 bpy.ops.object.select_all(action='DESELECT')
 for o in merged:o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=ASSET+'/'+name+'.glb',export_format='GLB',use_selection=True,export_yup=True,export_animations=False,export_cameras=False,export_lights=False)
 assets[name]=merged;current=[]

for name,team in [('allied-trooper',blue),('enemy-trooper',coral)]:
 # Blender -Y is glTF +Z. Robot, not a named humanoid character.
 for x in [-.17,.17]:
  cube('Stubby foot',(x,-.03,.075),(.235,.32,.15),'dark',b=.035)
  cube('Leg piston',(x,0,.20),(.14,.16,.23),'ivory',b=.018)
 cube('Ivory body',(0,0,.43),(.45,.30,.39),'light',b=.065)
 cube('Team chest',(0,-.18,.47),(.32,.075,.26),team=team,b=.035)
 cube('Back power pack',(0,.19,.45),(.28,.16,.26),team=team,b=.035)
 for x in [-.30,.30]:cube('Mechanical arm',(x,0,.44),(.16,.22,.32),'ivory',b=.035)
 cube('Head shell',(0,-.008,.79),(.54,.40,.37),'light',b=.085)
 cube('Team helmet',(0,.013,.91),(.51,.39,.23),team=team,b=.075)
 cube('Continuous dark visor',(0,-.216,.775),(.385,.047,.10),'dark',b=.025)
 cube('Helmet stripe',(0,-.009,1.031),(.070,.255,.016),'light',b=.004)
 close(name)

# A compact square watchfort. TEAM_BLUE is deliberately replaceable by the game.
cube('Stone plinth',(0,0,.13),(2.10,2.00,.26),'sand',b=.10)
cube('Cream foot course',(0,0,.30),(1.98,1.88,.20),'light',b=.065)
cube('Fort walls',(0,0,1.01),(1.60,1.50,1.35),'ivory',b=.095)
cube('Roof rim',(0,0,1.72),(1.94,1.82,.26),team=blue,b=.06)
roof('Hipped fort roof',(0,0,1.83),1.78,1.64,.48,blue)
cube('Top roof cap',(0,0,2.36),(.83,.73,.17),team=blue,b=.03)
for x in [-.74,.74]:
 for y in [-.69,.69]:
  cube('Corner masonry',(x,y,1.14),(.31,.31,1.38),'light',b=.04)
  cube('Corner cap',(x,y,1.83),(.40,.40,.19),team=blue,b=.035)
# Dark entrance inset and thick door frame.
cube('Gate darkness',(0,-.765,.70),(.55,.045,.88),'dark',b=.065)
for x in [-.335,.335]:cube('Gate jamb',(x,-.82,.65),(.13,.13,.91),'light',b=.022)
cube('Gate lintel',(0,-.82,1.13),(.78,.14,.15),'light',b=.025)
cyl('Team badge',(0,-.914,1.45),.16,.055,team=blue,n=8,rot=(math.pi/2,0,0))
for x in [-.59,.59]:cube('Front stripe',(x,-.82,1.08),(.17,.035,.38),team=blue,b=.01)
close('fort')

cube('Keep foundation',(0,0,.16),(3,2.7,.32),'sand',b=.12)
cube('Keep cream course',(0,0,.35),(2.86,2.56,.20),'light',b=.08)
cube('Keep central hall',(0,.16,1.20),(2.05,1.93,1.78),'ivory',b=.10)
roof('Wide lower roof',(0,.16,2.04),2.43,2.22,.62,teal)
cube('Keep upper storey',(0,.20,2.53),(1.20,1.14,.77),'light',b=.07)
roof('Upper hip roof',(0,.20,2.88),1.53,1.42,.55,teal)
cube('Roof ridge',(0,.20,3.46),(.74,.66,.16),team=teal,b=.04)
for x in [-1.02,1.02]:
 cube('Side pillar',(x,-.73,1.0),(.53,.67,1.40),'light',b=.07)
 roof('Pillar roof',(x,-.73,1.65),.70,.84,.29,teal)
cube('Keep entrance',(0,-.823,.83),(.75,.06,1.08),'dark',b=.08)
for x in [-.455,.455]:cube('Tall gate jamb',(x,-.87,.85),(.16,.16,1.18),'light',b=.025)
cube('Wide gate lintel',(0,-.87,1.46),(1.10,.17,.18),'light',b=.03)
cyl('Keep gold seal',(0,-.88,1.78),.20,.045,'gold',n=8,rot=(math.pi/2,0,0))
for x in [-.33,.33]:cube('Upper windows',(x,-.391,2.58),(.19,.045,.27),'dark',b=.022)
close('home-core')

cyl('Tree trunk',(0,0,.44),.16,.88,'trunk',n=7)
ico('Faceted lower canopy',(0,0,1.16),(.70,.64,.67),'leaf',sub=1)
ico('Faceted upper canopy',(.04,.01,1.61),(.51,.48,.53),'leaf2',sub=1)
close('tree')
ico('Mossy low rock',(0,0,.275),(.62,.46,.275),'stone',sub=1)
close('rock')
cyl('Banner plinth',(0,0,.075),.30,.15,'sand',n=8)
cyl('Gold pole',(0,0,.94),.046,1.72,'gold',n=8)
ico('Pole finial',(0,0,1.82),(.085,.085,.085),'gold',sub=1)
# Thick solid flag, so the geometry reads from either camera side.
v=[(.04,-.025,1.65),(.72,-.025,1.62),(.56,-.025,1.38),(.72,-.025,1.15),(.04,-.025,1.18),(.04,.025,1.65),(.72,.025,1.62),(.56,.025,1.38),(.72,.025,1.15),(.04,.025,1.18)]
f=[(0,4,3,2,1),(5,6,7,8,9)]+[(i,(i+1)%5,(i+1)%5+5,i+5) for i in range(5)]
me=bpy.data.meshes.new('Banner mesh');me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new('Team banner',me);scene.collection.objects.link(o);finish(o,'Team banner',team=blue)
close('banner')

manifest={'title':'Twin Forts / 쌍둥이 요새','provenance':'Original geometry created from primitives and custom vertices in Blender by this project. No downloaded models, textures, IP, or third-party character designs. Image key art generated with built-in OpenAI image generation; separate from game geometry.','axis':'glTF: +Y up, +Z forward, ground y=0; Blender authoring: +Z up, -Y forward.','materials':'TOY_BODY_VERTEX_COLOR shared material uses COLOR_0. TEAM_BLUE / TEAM_CORAL / TEAM_TEAL may be recolored after clone. Robots have two primitives (2 draw calls). No armature; animate model root.','assets':{}}
for name,objs in assets.items():
 pts=[o.matrix_world@Vector(v) for o in objs for v in o.bound_box];lo=[min(v[i] for v in pts) for i in range(3)];hi=[max(v[i] for v in pts) for i in range(3)];tris=0
 for o in objs:o.data.calc_loop_triangles();tris+=len(o.data.loop_triangles)
 manifest['assets'][name]={'file':name+'.glb','bytes':os.path.getsize(ASSET+'/'+name+'.glb'),'triangles':tris,'drawCalls':len(objs),'gltfBounds':{'min':[lo[0],lo[2],-hi[1]],'max':[hi[0],hi[2],-lo[1]]}}
with open(ASSET+'/manifest.json','w') as f:json.dump(manifest,f,indent=2,ensure_ascii=False)
# Save reusable original meshes inside an excluded collection, then render a composed game-world cover.
orig=bpy.data.collections.new('Original export meshes');scene.collection.children.link(orig)
for objs in assets.values():
 for o in objs:
  for c in list(o.users_collection):c.objects.unlink(o)
  orig.objects.link(o);o.hide_render=True;o.hide_set(True)
def show(name,pos,scale=1,angle=0,enemy=False):
 root=bpy.data.objects.new('Cover '+name,None);scene.collection.objects.link(root);root.location=pos;root.scale=(scale,scale,scale);root.rotation_euler.z=angle
 for src in assets[name]:
  o=src.copy();o.data=src.data.copy() if enemy else src.data;scene.collection.objects.link(o);o.hide_render=False;o.hide_set(False);o.parent=root;o.location=(0,0,0)
  if enemy:
   for i,m in enumerate(o.data.materials):
    if m.name.startswith('TEAM_'):o.data.materials[i]=coral
 return root
# Tabletop arena: 2 paths, horizontal canal, two back forts, with model troops near camera.
cube('Floating island rock',(0,0,-.49),(10,12,.85),'side',b=.35)
cube('Grass island top',(0,0,-.09),(10.12,12.12,.23),'grass',b=.23)
cube('Turquoise canal',(0,.20,.063),(10.14,1.5,.095),'water',b=.04)
for x in [-2.45,2.45]:
 cube('Sand attack lane',(x,0,.035),(1.50,10.4,.07),'path',b=.08)
 cube('Raised bridge',(x,.20,.19),(1.70,1.85,.30),'light',b=.07)
 for y in [-.43,.0,.43,.84]:cube('Bridge plank line',(x,y,.347),(1.61,.034,.012),'sand',b=0)
 for xx in [x-.84,x+.84]:cube('Low bridge rail',(xx,.20,.43),(.16,1.90,.21),'sand',b=.03)
 show('fort',(x,4.0,.05),1,enemy=True)
 show('banner',(x+1.17,3.9,.05),.78,enemy=True)
show('home-core',(0,-4.5,.05),.95)
for x0,qty in [(-2.45,6),(2.45,9)]:
 for i in range(qty):
  x=x0+(i%3-1)*.57;y=-.9-(i//3)*.7
  show('allied-trooper',(x,y,.075),.80,math.pi+.07*(i%2))
for x in [-2.5,2.5]:
 for k in range(3):show('enemy-trooper',(x+(k-1)*.46,2.27,.075),.63,0)
for x,y,s in [(-4.15,-4,.86),(4.15,-3.2,.85),(-4.2,1.8,.80),(4.2,4.65,.94),(-.7,5.2,.78)]:show('tree',(x,y,0),s)
for x,y,s in [(-4.1,-1.2,.76),(4.3,1.6,.68),(-3.85,4.8,.61),(.4,-2.4,.45),(4.2,-5,.52)]:show('rock',(x,y,.015),s)
# Large front robot is the cover focal object; it is the very same exported mesh.
show('allied-trooper',(-3.82,-4.45,.05),1.63,-.20)
# Studio ground, soft light and restrained bright grading.
cube('Backdrop',(0,0,-1.02),(200,200,.18),(.016,.105,.14),b=0)
world=bpy.data.worlds.new('Teal studio');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.17,.32,.34,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5

def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
def light(name,pos,power,size,color):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.size=size;d.color=color;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=pos;aim(o,(0,0,0))
light('Warm broad key',(-8,-5,15),1800,8,(1,.89,.68))
light('Cool fill',(8,-1,10),850,9,(.61,.87,1))
light('Back sun',(2,10,13),1300,7,(1,.92,.68))
d=bpy.data.cameras.new('Game cover camera');cam=bpy.data.objects.new('Game cover camera',d);scene.collection.objects.link(cam);cam.location=(10,-16,15);aim(cam,(0,.1,1.5));d.type='ORTHO';d.ortho_scale=26;scene.camera=cam
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True;scene.render.image_settings.file_format='PNG';scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
# Camera-facing title is native Blender text, not raster post-processing.
font=bpy.data.fonts.load(args.font_path) if os.path.exists(args.font_path) else bpy.data.fonts.get('Bfont')
def caption(name,text,size,loc,color):
 cu=bpy.data.curves.new(name,'FONT');cu.body=text;cu.font=font;cu.align_x='CENTER';cu.size=size;cu.extrude=.006;cu.bevel_depth=.004;cu.bevel_resolution=1;o=bpy.data.objects.new(name,cu);scene.collection.objects.link(o);o.parent=cam;o.location=loc;o.rotation_euler=(0,0,0);ma=material(name+' ink',color);ma.node_tree.nodes.get('Principled BSDF').inputs['Emission Color'].default_value=(*color,1);ma.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=1.0;cu.materials.append(ma);return o
headline=caption('Cover title','쌍둥이 요새',1.34,(0,5.02,-12),(1,.91,.60))
subline=caption('Cover tagline','나누어 출동! 함께 승리!',.38,(0,4.36,-11.97),(.76,.95,1))
scene.render.resolution_x=1200;scene.render.resolution_y=630;scene.render.filepath=os.path.join(GAME,'thumb.png')
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/twin-forts-assets.blend')
bpy.ops.render.render(write_still=True)
# A taller composition exposes the complete tabletop while keeping text above it.
cam.location=(10,-16,18);aim(cam,(0,.1,.3));d.ortho_scale=17.7
headline.location=(0,7.0,-12);headline.data.size=1.10;subline.location=(0,6.38,-11.97);subline.data.size=.34
scene.render.resolution_x=1080;scene.render.resolution_y=1080;scene.render.filepath=os.path.join(GAME,'square.png');bpy.ops.render.render(write_still=True)
# Preserve font-free editable geometry in the portable source file.
for obj in list(scene.objects):
 if obj.type=='FONT':
  bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj;bpy.ops.object.convert(target='MESH')
for f in list(bpy.data.fonts):
 if f.users==0 and f.filepath:bpy.data.fonts.remove(f)
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/twin-forts-assets.blend',compress=True)
print('TWIN_ASSETS_DONE '+json.dumps(manifest))

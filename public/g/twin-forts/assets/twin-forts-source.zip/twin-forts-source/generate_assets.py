import bpy, math, json, os, random, argparse
from mathutils import Vector, Matrix
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'../..'))
parser=argparse.ArgumentParser();parser.add_argument('--output-dir',default=os.path.join(ROOT,'public/g/twin-forts'));parser.add_argument('--source-dir',default=os.path.dirname(__file__));parser.add_argument('--font-path',default='/System/Library/Fonts/AppleSDGothicNeo.ttc');args=parser.parse_args(__import__('sys').argv[__import__('sys').argv.index('--')+1:] if '--' in __import__('sys').argv else [])
GAME=os.path.abspath(args.output_dir);ASSET=os.path.join(GAME,'assets');OUT=os.path.abspath(args.source_dir);os.makedirs(OUT,exist_ok=True);os.makedirs(ASSET,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True);scene=bpy.context.scene;scene.name='Twin Forts sculpted battle workshop v2'
current=[];assets={}
def material(name,color,metal=0,rough=.58):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m

def vmat(name,metal=0,rough=.65):
 m=material(name,(1,1,1),metal,rough);p=m.node_tree.nodes.get('Principled BSDF');n=m.node_tree.nodes.new('ShaderNodeVertexColor');n.layer_name='Color';m.node_tree.links.new(n.outputs['Color'],p.inputs['Base Color']);return m
body=vmat('TOY_BODY_VERTEX_COLOR');metal=vmat('ARMOR_METAL_VERTEX_COLOR',.52,.36)
blue=material('TEAM_BLUE',(.015,.18,.67),.20,.40);coral=material('TEAM_CORAL',(.77,.055,.017),.18,.40);teal=material('TEAM_TEAL',(.009,.32,.49),.20,.4)
C={'ivory':(.57,.61,.56),'light':(.81,.81,.65),'dark':(.013,.025,.034),'sand':(.32,.28,.19),'stone':(.29,.35,.34),'gold':(.88,.43,.055),'trunk':(.18,.078,.026),'wood':(.38,.18,.055),'wood2':(.49,.25,.075),'leaf':(.10,.33,.025),'leaf2':(.25,.50,.045),'leaf3':(.35,.60,.058),'grass':(.20,.46,.056),'side':(.21,.20,.135),'water':(.005,.235,.42),'path':(.74,.41,.085),'steel':(.19,.25,.28),'silver':(.48,.57,.60),'eyes':(.23,.94,1),'rubber':(.025,.045,.045)}
def finish(o,name,col='ivory',team=None,bevel=0,segments=2,metallic=False,smooth=False):
 o.name=name
 if bevel:
  b=o.modifiers.new('Sculpted round edges','BEVEL');b.width=bevel;b.segments=segments;b.affect='EDGES'
  bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=b.name)
 if team:o.data.materials.append(team)
 else:
  o.data.materials.append(metal if metallic else body);ca=o.data.color_attributes.new(name='Color',type='FLOAT_COLOR',domain='CORNER');c=C.get(col,col)
  for d in ca.data:d.color=(*c,1)
 for poly in o.data.polygons:poly.use_smooth=smooth or bool(bevel)
 if bevel:
  try:
   n=o.modifiers.new('Weighted sculptural normals','WEIGHTED_NORMAL');n.keep_sharp=True;n.weight=50;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=n.name)
  except Exception:pass
 current.append(o);return o

def cube(name,loc,dims,col='ivory',team=None,b=.035,segments=2,metallic=False):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.scale=dims;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,col,team,b,segments,metallic)
def cyl(name,loc,r,d,col='ivory',team=None,n=12,rot=None,b=0,metallic=False):
 bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=d,location=loc,rotation=rot or (0,0,0));return finish(bpy.context.object,name,col,team,b,2,metallic,True)
def ico(name,loc,scale,col='leaf',sub=2,smooth=True,team=None,metallic=False):
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub,radius=1,location=loc);o=bpy.context.object;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,col,team,metallic=metallic,smooth=smooth)
def lathe(name,profile,loc,col='steel',team=None,n=12,rot=None,metallic=False,caps=True):
 v=[(r*math.cos(2*math.pi*j/n),r*math.sin(2*math.pi*j/n),z) for z,r in profile for j in range(n)]
 f=[(i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j) for i in range(len(profile)-1) for j in range(n)]
 if caps:f+=[tuple(reversed(range(n))),tuple((len(profile)-1)*n+j for j in range(n))]
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);o.location=loc
 if rot:o.rotation_euler=rot
 return finish(o,name,col,team,metallic=metallic,smooth=True)
def shield(name,loc,w,h,depth,col='silver',team=None,metallic=False):
 outline=[(-w*.5,h*.40),(-w*.34,h*.5),(w*.34,h*.5),(w*.5,h*.4),(w*.48,-h*.25),(0,-h*.5),(-w*.48,-h*.25)]
 v=[(x,y,z) for y in [-depth/2,depth/2] for x,z in outline];n=len(outline);f=[tuple(reversed(range(n))),tuple(range(n,n*2))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);o.location=loc;return finish(o,name,col,team,.015,2,metallic)
def close(name):
 global current
 groups={}
 for o in current:groups.setdefault(o.data.materials[0].name,[]).append(o)
 merged=[]
 for key,objs in groups.items():
  bpy.ops.object.select_all(action='DESELECT')
  for o in objs:o.select_set(True)
  bpy.context.view_layer.objects.active=objs[0]
  if len(objs)>1:bpy.ops.object.join()
  o=bpy.context.object;scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');o.name=name+'_'+key;merged.append(o)
 bpy.context.view_layer.update()
 bottom=min((o.matrix_world@v.co).z for o in merged for v in o.data.vertices)
 for o in merged:
  transform=o.matrix_world.copy()
  for v in o.data.vertices:v.co=transform@v.co-Vector((0,0,bottom))
  o.matrix_world=Matrix.Identity(4)
 bpy.ops.object.select_all(action='DESELECT')
 for o in merged:o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=ASSET+'/'+name+'.glb',export_format='GLB',use_selection=True,export_yup=True,export_animations=False,export_cameras=False,export_lights=False)
 assets[name]=merged;current=[]

for name,team in [('allied-trooper',blue),('enemy-trooper',coral)]:
 # Big helmet, wide shoulder armour and protruding shield survive an overhead small-scale camera.
 for x in [-.19,.19]:
  cube('Heavy sole',(x,-.035,.055),(.28,.36,.11),'rubber',b=.03,segments=1)
  cube('Rounded armored boot',(x,-.04,.16),(.265,.32,.23),'silver',b=.058,metallic=True)
  cube('Dark articulated leg',(x,.015,.30),(.15,.18,.21),'dark',b=.028,segments=1)
 cube('Undersuit torso',(0,.015,.56),(.47,.29,.38),'dark',b=.08,segments=1)
 cube('Sculpted cuirass',(0,-.047,.62),(.48,.32,.37),'silver',b=.082,metallic=True)
 cube('Team chest inset',(0,-.222,.66),(.31,.06,.20),team=team,b=.031,segments=1)
 cube('Utility backpack',(0,.216,.63),(.33,.19,.30),'steel',b=.05,segments=1,metallic=True)
 for x in [-.36,.36]:
  ico('Heavy round pauldron',(x,.0,.74),(.205,.22,.195),team=team,sub=2)
  cube('Separate gauntlet',(x,-.025,.46),(.22,.255,.24),'silver',b=.046,segments=1,metallic=True)
 # Rounded dome with broad brim, entirely original machine silhouette.
 lathe('Armored rounded helmet',[(.79,.25),(.82,.33),(.88,.355),(1.035,.345),(1.18,.255),(1.245,.105),(1.25,.008)],(0,0,0),team=team,n=16)
 cube('Black inset face',(0,-.370,.94),(.40,.05,.13),'dark',b=.035,segments=1)
 cube('Bright optical slit',(0,-.403,.954),(.30,.025,.036),'eyes',b=.008,segments=1)
 cube('Silver brow guard',(0,-.383,1.031),(.42,.057,.061),'silver',b=.013,segments=1,metallic=True)
 shield('Thick shield rim',(-.39,-.26,.54),.43,.56,.095,'silver',metallic=True)
 shield('Shield enamel',(-.39,-.321,.548),.34,.455,.035,team=team)
 cyl('Shield metal boss',(-.39,-.36,.59),.055,.025,'gold',n=8,rot=(math.pi/2,0,0),metallic=True)
 close(name)

def cannon(x,y,z,s=1,team=blue):
 cyl('Turret bearing',(x,y,z),.39*s,.13*s,'dark',n=16,metallic=True)
 ico('Armored gun cradle',(x,y,z+.23*s),(.36*s,.37*s,.29*s),team=team,sub=2)
 for xx in [-.36,.36]:cyl('Cradle axle',(x+xx*s,y,z+.23*s),.14*s,.085*s,'gold',n=12,rot=(0,math.pi/2,0),metallic=True)
 # The muzzle is an actual dark recessed hole with a thick layered metal lip.
 lathe('Broad cannon barrel',[(0,.19*s),(.13*s,.245*s),(.43*s,.21*s),(.65*s,.27*s),(.76*s,.27*s),(.78*s,.17*s),(.50*s,.15*s),(.0,.15*s),(.0,.19*s)],(x,y-.02*s,z+.27*s),'steel',n=16,rot=(math.pi/2,0,0),metallic=True,caps=False)
 cyl('Dark bore inset',(x,y-.535*s,z+.27*s),.148*s,.016*s,'dark',n=16,rot=(math.pi/2,0,0))
 lathe('Gold muzzle rim',[(0,.272*s),(.065*s,.278*s),(.065*s,.17*s),(0,.17*s),(0,.272*s)],(x,y-.674*s,z+.27*s),'gold',n=16,rot=(math.pi/2,0,0),metallic=True,caps=False)

def fortress(large=False):
 t=teal if large else blue;w=3.0 if large else 2.16;d=2.44 if large else 1.86;h=2.08 if large else 1.35
 cube('Massive dark foundation',(0,0,.14),(w+.10,d+.10,.28),'sand',b=.08)
 cube('Dressed stone plinth',(0,0,.36),(w,d,.21),'light',b=.055)
 cube('Main stone blockhouse',(0,.02,.46+h/2),(w-.35,d-.35,h),'stone',b=.085)
 # Deliberate masonry bands produce thickness and readable lit ledges.
 cube('Lower stone belt',(0,0,.61),(w-.13,d-.13,.17),'ivory',b=.026)
 cube('Upper cornice',(0,0,h+.46),(w+.02,d+.02,.20),'light',b=.045)
 cube('Open gun deck',(0,0,h+.59),(w-.13,d-.13,.105),'wood',b=.015)
 for side in [-1,1]:
  x=side*(w/2-.24)
  # Broad circular side bastions make the silhouette a fortress, not a roofed house.
  cyl('Corner defense tower',(x,.05,.48+h*.54),.34,h*1.08,'ivory',n=12,b=.026)
  cyl('Bastion team belt',(x,.05,h+.33),.355,.19,team=t,n=12,b=.022)
  cyl('Bastion stone cap',(x,.05,h+.52),.40,.18,'light',n=12,b=.024)
  for y in [-d*.39,d*.39]:cube('Raised merlon',(x,y,h+.75),(.39,.30,.34),'light',b=.045)
 # Low back parapet and front crenels frame the gun without obscuring it.
 cube('Rear parapet',(0,d/2-.095,h+.79),(w-.35,.24,.34),'ivory',b=.045)
 for x in [-w*.23,w*.23]:cube('Front parapet',(x,-d/2+.085,h+.73),(.37,.25,.24),'light',b=.035)
 # Stonework blocks on façade add scale and some hand-built irregularity.
 for row in range(2 if not large else 3):
  for side in [-1,1]:cube('Face masonry block',(side*(w*.35),-d/2+.025,.79+row*.32),(.35,.085,.22),'ivory',b=.025)
 gatew=.65 if not large else .93;gateh=.91 if not large else 1.35;gy=-d/2-.027
 cube('Recessed portal',(0,gy,.56+gateh/2),(gatew+.13,.065,gateh+.08),'dark',b=.048)
 for i in [-1,0,1]:cube('Oak gate plank',(i*gatew/3,gy-.051,.56+gateh/2),(gatew/3-.018,.055,gateh),'wood2' if i==0 else 'wood',b=.018)
 for z in [.72,.56+gateh-.18]:cube('Iron door strap',(0,gy-.095,z),(gatew,.045,.075),'steel',b=.012,metallic=True)
 for x in [-gatew/2-.105,gatew/2+.105]:cube('Portal jamb',(x,gy-.027,.55+gateh/2),(.15,.17,gateh+.18),'light',b=.03)
 cube('Portal top lintel',(0,gy-.028,.62+gateh),(gatew+.37,.19,.18),'light',b=.036)
 shield('Team heraldic plate',(0,gy-.16,h+.36),.45,.44,.07,team=t)
 # Original simple rivet insignia; deliberately no crown or copied logo.
 cyl('Heraldic rivet',(0,gy-.21,h+.39),.06,.027,'gold',n=8,rot=(math.pi/2,0,0),metallic=True)
 if large:
  cannon(-.66,.05,h+.66,.84,t);cannon(.66,.05,h+.66,.84,t)
  cube('Central command block',(0,.54,h+1.00),(.56,.53,.66),team=t,b=.10)
  cyl('Command beacon',(0,.54,h+1.41),.15,.19,'gold',n=12,b=.025,metallic=True)
 else:cannon(0,.06,h+.64,1,t)
fortress();close('fort')
fortress(True);close('home-core')

cyl('Flared tree trunk',(0,0,.46),.21,.92,'trunk',n=10,b=.025)
for a in [0,2.1,4.2]:
 o=cyl('Visible spreading root',(.16*math.cos(a),.16*math.sin(a),.12),.11,.48,'trunk',n=8,b=.018);o.rotation_euler=(.58*math.sin(a),.58*math.cos(a),0)
ico('Wide shaded canopy',(-.11,.02,1.12),(.79,.65,.61),'leaf',sub=3)
ico('Round upper crown',(.03,.045,1.72),(.60,.58,.59),'leaf2',sub=3)
ico('Sunlit canopy lobe',(.35,-.12,1.38),(.46,.43,.46),'leaf3',sub=2)
close('tree')
ico('Rounded stone',(-.07,0,.28),(.53,.41,.30),'stone',sub=2,smooth=False)
ico('Smaller attached stone',(.28,.12,.20),(.29,.24,.22),'ivory',sub=1,smooth=False)
# Geometry follows an exact ground plane even with irregular low-poly rock vertices.
for o in current:
 for v in o.data.vertices:
  if v.co.z+o.location.z<0:v.co.z=-o.location.z
close('rock')
cyl('Banner stone anchor',(0,0,.10),.28,.20,'stone',n=10,b=.025)
cyl('Wooden flagstaff',(0,0,.99),.06,1.81,'wood',n=12)
for z in [.26,1.69]:cyl('Pole iron collar',(0,0,z),.084,.10,'gold',n=12,b=.009,metallic=True)
ico('Golden finial',(0,0,1.98),(.10,.10,.17),'gold',sub=1,metallic=True)
# Waved, solid textile pennant with a heavy team stripe.
v=[]
for yy in [-.015,.015]:
 for i in range(6):
  x=.07+i*.14;wave=math.sin(i*1.20)*.055
  for z in [1.67-i*.017,1.10+i*.005]:v.append((x,yy+wave,z))
f=[]
for offset in [0,12]:
 for i in range(5):a=offset+i*2;f.append((a,a+2,a+3,a+1))
for i in range(5):a=i*2;f.extend([(a,a+12,a+14,a+2),(a+1,a+3,a+15,a+13)])
f.extend([(0,1,13,12),(10,22,23,11)])
me=bpy.data.meshes.new('Woven waving pennant');me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new('Original team pennant',me);scene.collection.objects.link(o);finish(o,o.name,team=blue,smooth=True)
close('banner')

manifest={'title':'Twin Forts / 쌍둥이 요새','provenance':'Original geometry created from primitives and custom vertices in Blender by this project. No downloaded models, textures, IP, or third-party character designs. Image key art generated with built-in OpenAI image generation; separate from game geometry.','axis':'glTF: +Y up, +Z forward, ground y=0; Blender authoring: +Z up, -Y forward.','materials':'TOY_BODY_VERTEX_COLOR shared material uses COLOR_0. TEAM_BLUE / TEAM_CORAL / TEAM_TEAL may be recolored after clone. Robots have three primitives (3 draw calls), including a metal material; preserve COLOR_0 on both vertex-color materials. No armature; animate model root.','assets':{}}
for name,objs in assets.items():
 pts=[o.matrix_world@Vector(v) for o in objs for v in o.bound_box];lo=[min(v[i] for v in pts) for i in range(3)];hi=[max(v[i] for v in pts) for i in range(3)];tris=0
 for o in objs:o.data.calc_loop_triangles();tris+=len(o.data.loop_triangles)
 manifest['assets'][name]={'file':name+'.glb','bytes':os.path.getsize(ASSET+'/'+name+'.glb'),'triangles':tris,'drawCalls':len(objs),'gltfBounds':{'min':[lo[0],lo[2],-hi[1]],'max':[hi[0],hi[2],-lo[1]]}}
with open(ASSET+'/manifest.json','w') as f:json.dump(manifest,f,indent=2,ensure_ascii=False)
# Save reusable original meshes inside an excluded collection, then render a composed game-world cover.
orig=bpy.data.collections.new('Original export meshes');scene.collection.children.link(orig)
for objs in assets.values():
 for o in objs:
  for c in list(o.users_collection):c.objects.unlink(o)
  orig.objects.link(o);o.hide_render=True;o.hide_set(True)
def show(name,pos,scale=1,angle=0,enemy=False):
 root=bpy.data.objects.new('Cover '+name,None);scene.collection.objects.link(root);root.location=pos;root.scale=(scale,scale,scale);root.rotation_euler.z=angle
 for src in assets[name]:
  o=src.copy();o.data=src.data.copy() if enemy else src.data;scene.collection.objects.link(o);o.hide_render=False;o.hide_set(False);o.parent=root;o.location=(0,0,0)
  if enemy:
   for i,m in enumerate(o.data.materials):
    if m.name.startswith('TEAM_'):o.data.materials[i]=coral
 return root
# Tabletop arena: 2 paths, horizontal canal, two back forts, with model troops near camera.
cube('Floating island rock',(0,0,-.49),(10,12,.85),'side',b=.35)
cube('Grass island top',(0,0,-.09),(10.12,12.12,.23),'grass',b=.23)
for ix in range(8):
 for iy in range(10):
  if (ix+iy)%2==0:cube('Checker turf cut',(-4.38+ix*1.25,-5.42+iy*1.2,.026),(1.23,1.18,.008),(.22,.48,.064),b=.004)
for sx in [-1,1]:
 for iy in range(10):
  cube('Arena stone edge',(sx*4.91,-5.4+iy*1.2,.15),(.30,1.13,.30),'ivory',b=.036)
for sy in [-1,1]:
 for ix in range(8):cube('Arena end edge',(-4.35+ix*1.24,sy*5.91,.15),(1.17,.28,.30),'ivory',b=.032)
cube('Turquoise canal',(0,.20,.063),(10.14,1.5,.095),'water',b=.04)
for x in [-2.45,2.45]:
 cube('Sand attack lane',(x,0,.035),(1.50,10.4,.07),'path',b=.08)
 cube('Raised bridge',(x,.20,.19),(1.70,1.85,.30),'light',b=.07)
 for y in [-.43,.0,.43,.84]:cube('Bridge plank line',(x,y,.347),(1.61,.034,.012),'sand',b=0)
 for xx in [x-.84,x+.84]:cube('Low bridge rail',(xx,.20,.43),(.16,1.90,.21),'sand',b=.03)
 show('fort',(x,4.0,.05),1,enemy=True)
 show('banner',(x+1.17,3.9,.05),.78,enemy=True)
show('home-core',(0,-4.5,.05),.95)
for x0,qty in [(-2.45,6),(2.45,9)]:
 for i in range(qty):
  x=x0+(i%3-1)*.57;y=-.9-(i//3)*.7
  show('allied-trooper',(x,y,.075),.80,math.pi+.07*(i%2))
for x in [-2.5,2.5]:
 for k in range(3):show('enemy-trooper',(x+(k-1)*.46,2.27,.075),.63,0)
for x,y,s in [(-4.15,-4,.86),(4.15,-3.2,.85),(-4.2,1.8,.80),(4.2,4.65,.94),(-.7,5.2,.78)]:show('tree',(x,y,0),s)
for x,y,s in [(-4.1,-1.2,.76),(4.3,1.6,.68),(-3.85,4.8,.61),(.4,-2.4,.45),(4.2,-5,.52)]:show('rock',(x,y,.015),s)
# Large front robot is the cover focal object; it is the very same exported mesh.
show('allied-trooper',(-3.82,-4.45,.05),1.63,-.20)
# Studio ground, soft light and restrained bright grading.
cube('Backdrop',(0,0,-1.02),(200,200,.18),(.016,.105,.14),b=0)
world=bpy.data.worlds.new('Teal studio');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.17,.32,.34,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5

def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
def light(name,pos,power,size,color):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.size=size;d.color=color;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=pos;aim(o,(0,0,0))
light('Warm broad key',(-8,-5,15),1800,8,(1,.89,.68))
light('Cool fill',(8,-1,10),850,9,(.61,.87,1))
light('Back sun',(2,10,13),1300,7,(1,.92,.68))
d=bpy.data.cameras.new('Game cover camera');cam=bpy.data.objects.new('Game cover camera',d);scene.collection.objects.link(cam);cam.location=(10,-16,15);aim(cam,(0,.1,1.5));d.type='ORTHO';d.ortho_scale=26;scene.camera=cam
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True;scene.render.image_settings.file_format='PNG';scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
# Camera-facing title is native Blender text, not raster post-processing.
font=bpy.data.fonts.load(args.font_path) if os.path.exists(args.font_path) else bpy.data.fonts.get('Bfont')
def caption(name,text,size,loc,color):
 cu=bpy.data.curves.new(name,'FONT');cu.body=text;cu.font=font;cu.align_x='CENTER';cu.size=size;cu.extrude=.006;cu.offset=.013;cu.bevel_depth=.004;cu.bevel_resolution=1;o=bpy.data.objects.new(name,cu);scene.collection.objects.link(o);o.parent=cam;o.location=loc;o.rotation_euler=(0,0,0);ma=material(name+' ink',color);ma.node_tree.nodes.get('Principled BSDF').inputs['Emission Color'].default_value=(*color,1);ma.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=1.0;cu.materials.append(ma);return o
headline=caption('Cover title','쌍둥이 요새',2.4,(0,4.72,-12),(1,.91,.60))
subline=caption('Cover tagline','나누어 출동! 함께 승리!',.42,(0,4.02,-11.97),(.76,.95,1))
scene.render.resolution_x=1200;scene.render.resolution_y=630;scene.render.filepath=os.path.join(GAME,'thumb.png')
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/twin-forts-assets.blend')
bpy.ops.render.render(write_still=True)
# A taller composition exposes the complete tabletop while keeping text above it.
cam.location=(10,-16,18);aim(cam,(0,.1,.3));d.ortho_scale=17.7
headline.location=(0,6.80,-12);headline.data.size=1.80;subline.location=(0,6.02,-11.97);subline.data.size=.38
scene.render.resolution_x=1080;scene.render.resolution_y=1080;scene.render.filepath=os.path.join(GAME,'square.png');bpy.ops.render.render(write_still=True)
# Preserve font-free editable geometry in the portable source file.
for obj in list(scene.objects):
 if obj.type=='FONT':
  bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj;bpy.ops.object.convert(target='MESH')
for f in list(bpy.data.fonts):
 if f.users==0 and f.filepath:bpy.data.fonts.remove(f)
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/twin-forts-assets.blend',compress=True)
print('TWIN_ASSETS_DONE '+json.dumps(manifest))

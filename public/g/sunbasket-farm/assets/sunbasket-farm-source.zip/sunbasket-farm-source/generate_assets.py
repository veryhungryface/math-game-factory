import bpy, math, os, json, random, argparse, sys
from mathutils import Vector, Matrix
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'../..'))
p=argparse.ArgumentParser();p.add_argument('--output-dir',default=os.path.join(ROOT,'public/g/sunbasket-farm'));p.add_argument('--source-dir',default=os.path.dirname(__file__));p.add_argument('--font-path',default='/System/Library/Fonts/AppleSDGothicNeo.ttc');a=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
GAME=os.path.abspath(a.output_dir);OUT=os.path.abspath(a.source_dir);ASSET=GAME+'/assets';os.makedirs(ASSET,exist_ok=True);os.makedirs(OUT,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True);scene=bpy.context.scene;scene.name='Sunbasket Farm original orchard studio'
parts=[];assets={};random.seed(1709)
C={'cream':(.94,.81,.50),'ivory':(.99,.94,.75),'plaster':(.57,.19,.074),'peach':(.91,.53,.28),'wood':(.32,.135,.038),'woodlight':(.59,.31,.105),'woodwarm':(.74,.41,.16),'dark':(.055,.042,.025),'roof':(.012,.30,.30),'rooflight':(.024,.45,.40),'roofdark':(.009,.15,.18),'soil':(.26,.112,.034),'stone':(.52,.46,.30),'stone2':(.68,.62,.43),'leaf':(.036,.21,.009),'leaflight':(.14,.36,.019),'leafsun':(.24,.46,.029),'orange':(.97,.225,.016),'orangehi':(1,.44,.025),'red':(.78,.018,.014),'redhi':(1,.065,.021),'gold':(1,.63,.025),'gold2':(.84,.41,.018),'straw':(.80,.61,.24),'metal':(.14,.18,.15),'sky':(.22,.53,.65),'glass':(.08,.34,.45),'white':(.95,.98,.80),'grass':(.18,.38,.025),'grasslight':(.25,.43,.045)}
def mat(name,rough=.58):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes.new('ShaderNodeVertexColor');n.layer_name='Color';b=m.node_tree.nodes.get('Principled BSDF');m.node_tree.links.new(n.outputs['Color'],b.inputs['Base Color']);b.inputs['Roughness'].default_value=rough;return m
body=mat('FARM_VERTEX_COLOR');glass=mat('WINDOW_VERTEX_COLOR',.18);glass.node_tree.nodes.get('Principled BSDF').inputs['Metallic'].default_value=.3

def finish(o,name,col='wood',bevel=0,seg=2,smooth=False,gloss=False,tag=None):
 o.name=name
 if bevel:
  mod=o.modifiers.new('Soft hand-shaped corners','BEVEL');mod.width=bevel;mod.segments=seg;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 o.data.materials.append(glass if gloss else body);ca=o.data.color_attributes.new(name='Color',type='FLOAT_COLOR',domain='CORNER');c=C.get(col,col)
 for d in ca.data:d.color=(*c,1)
 for f in o.data.polygons:f.use_smooth=bool(bevel) or smooth
 if bevel:
  try:
   mod=o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');mod.keep_sharp=True;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
  except:pass
 if tag:o['asset_part']=tag
 parts.append(o);return o

def box(name,loc,size,col='wood',b=.035,seg=2,gloss=False,tag=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.scale=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,col,b,seg,gloss=gloss,tag=tag)
def cyl(name,loc,r,d,col='wood',n=12,rot=None,b=0,tag=None):
 bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=d,location=loc,rotation=rot or (0,0,0));return finish(bpy.context.object,name,col,b,smooth=True,tag=tag)
def ico(name,loc,size,col='leaf',sub=2,smooth=True):
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub,radius=1,location=loc);o=bpy.context.object;o.scale=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,col,smooth=smooth)
def sphere(name,loc,size,col='red',segments=12,rings=6):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,radius=1,location=loc);o=bpy.context.object;o.scale=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,col,smooth=True)
def lathe(name,profile,loc=(0,0,0),col='wood',n=12):
 v=[(r*math.cos(j*math.tau/n),r*math.sin(j*math.tau/n),z) for z,r in profile for j in range(n)]
 f=[(i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j) for i in range(len(profile)-1) for j in range(n)]+[tuple(reversed(range(n))),tuple((len(profile)-1)*n+j for j in range(n))]
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);o.location=loc;return finish(o,name,col,smooth=True)
def beam(name,start,end,width,depth=None,col='wood',b=.022,tag=None):
 delta=Vector(end)-Vector(start);o=box(name,(Vector(start)+Vector(end))/2,(width,depth or width,delta.length),col,b,tag=tag);o.rotation_euler=delta.to_track_quat('Z','Y').to_euler();return o

def leaf(name,start,end,width,col='leaflight',bend=.08):
 start=Vector(start);end=Vector(end);d=end-start;side=d.cross(Vector((0,0,1)))
 if side.length<.001:side=Vector((1,0,0))
 side.normalize();mid=start+d*.48+Vector((0,0,bend));ridge=mid+Vector((0,0,.022));v=[start,mid-side*width,end,mid+side*width,ridge,mid-Vector((0,0,.025))];f=[(0,1,4),(1,2,4),(2,3,4),(3,0,4),(0,5,1),(1,5,2),(2,5,3),(3,5,0)];me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);return finish(o,name,col,smooth=True)

def arch(name,loc,w,stem,col='wood',depth=.08,trim=0):
 r=w/2;outline=[(-r,0),(r,0),(r,stem)]+[(r*math.cos(t*math.pi/12),stem+r*math.sin(t*math.pi/12)) for t in range(1,13)]
 if not trim:
  n=len(outline);v=[(x,y,z) for y in [-depth/2,depth/2] for x,z in outline];f=[tuple(reversed(range(n))),tuple(range(n,n*2))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 else:
  inner=[(x*(w-2*trim)/w,z+trim if z==0 else z-trim*.3) for x,z in outline];n=len(outline);v=[(x,y,z) for y in [-depth/2,depth/2] for path in [outline,inner] for x,z in path];f=[]
  for i in range(n):
   j=(i+1)%n;f.extend([(i,j,n+j,n+i),(i+2*n,3*n+i,3*n+j,2*n+j),(i,i+2*n,j+2*n,j),(i+n,j+n,j+3*n,i+3*n)])
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);o.location=loc;return finish(o,name,col,.012,2)

def roof(name,profile,depth,col='roof',loc=(0,0,0),thick=.12):
 n=len(profile);v=[(x,y,z+dz) for dz in [0,-thick] for y in [-depth/2,depth/2] for x,z in profile];f=[]
 for i in range(n-1):f.extend([(i,i+1,n+i+1,n+i),(2*n+i,3*n+i,3*n+i+1,2*n+i+1),(i,2*n+i,2*n+i+1,i+1),(n+i,n+i+1,3*n+i+1,3*n+i)])
 f.extend([(0,n,3*n,2*n),(n-1,3*n-1,4*n-1,2*n-1)])
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);scene.collection.objects.link(o);o.location=loc;return finish(o,name,col,.03,2,smooth=True)

def close(name,normalize=None,rotor=False):
 global parts
 groups={}
 for o in parts:groups.setdefault((o.data.materials[0].name,o.get('asset_part','static')),[]).append(o)
 merged=[]
 for key,objs in groups.items():
  bpy.ops.object.select_all(action='DESELECT')
  for o in objs:o.select_set(True)
  bpy.context.view_layer.objects.active=objs[0]
  if len(objs)>1:bpy.ops.object.join()
  o=bpy.context.object;bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');o.name=name+'_'+key[0] if key[1]=='static' else 'windmill-rotor';merged.append(o)
 bpy.context.view_layer.update();bottom=min((o.matrix_world@v.co).z for o in merged for v in o.data.vertices);top=max((o.matrix_world@v.co).z for o in merged for v in o.data.vertices);scale=(normalize/(top-bottom)) if normalize else 1
 for o in merged:
  transform=o.matrix_world.copy()
  for v in o.data.vertices:v.co=(transform@v.co-Vector((0,0,bottom)))*scale
  o.matrix_world=Matrix.Identity(4)
  if o.name=='windmill-rotor':
   pivot=Vector((0,-.86,2.67))*scale-Vector((0,0,bottom*scale))
   for v in o.data.vertices:v.co-=pivot
   o.location=pivot
 if name=='strawberry':
  xs=[v.co.x for o in merged for v in o.data.vertices];width=max(xs)-min(xs);xy=.95/width
  for o in merged:
   for v in o.data.vertices:v.co.x*=xy;v.co.y*=xy
 bpy.ops.object.select_all(action='DESELECT')
 for o in merged:o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=ASSET+'/'+name+'.glb',export_format='GLB',use_selection=True,export_yup=True,export_animations=False,export_cameras=False,export_lights=False)
 assets[name]=merged;parts=[]

# Crop instances: single color material, unique silhouettes, exactly one metre high.
lathe('Sweet orange carrot',[(0,.018),(.10,.09),(.26,.18),(.44,.21),(.54,.13),(.56,.03)],col='orange',n=10)
for i in range(5):
 theta=i*math.tau/5;end=(math.cos(theta)*.28,math.sin(theta)*.28,.82+(i%2)*.13);leaf('Feathery carrot top',(0,0,.51),end,.10,'leaflight' if i%2 else 'leafsun',.10)
for z in [.18,.30,.40]:box('Root growth mark',(.01,-.17,z),(.14,.012,.018),'orangehi',b=0)
close('carrot',normalize=1)
for i in range(5):
 th=i*math.tau/5;leaf('Broad strawberry leaf',(0,0,.18),(.38*math.cos(th),.38*math.sin(th),.44+(i%2)*.04),.18,'leaflight' if i%2 else 'leaf',.12)
for i,(x,y,z,r) in enumerate([(-.15,-.10,.27,.22),(.17,.06,.30,.19)]):
 lathe('Ripe strawberry',[(0,.016),(.09,r*.66),(.22,r),(.34,r*.78),(.38,r*.24)],(x,y,z-.19),'red' if i else 'redhi',n=10)
 for k in range(5):
  th=k*math.tau/5;leaf('Berry crown',(x,y,z+.14),(x+.18*math.cos(th),y+.18*math.sin(th),z+.20),.045,'leafsun',.02)
 for dx,dz in [(-.065,.03),(.06,.01),(0,-.08)]:sphere('Golden strawberry seed',(x+dx,y-r*.86,z+dz),(.015,.008,.020),'gold',segments=6,rings=3)
close('strawberry',normalize=1)
cyl('Corn stalk',(0,0,.48),.035,.96,'leaf',n=8)
for i in range(4):
 th=i*2.15;leaf('Long arching corn leaf',(0,0,.22+i*.13),(.37*math.cos(th),.37*math.sin(th),.39+i*.13),.105,'leaflight' if i%2 else 'leafsun',.12)
lathe('Golden corn cob',[(0,.055),(.07,.12),(.35,.12),(.45,.075),(.49,.015)],(.11,-.015,.38),'gold',n=10)
for z in [.48,.57,.66,.75]:
 for ang in [math.pi*1.12,math.pi*1.5,math.pi*1.88]:
  box('Large kernel',(.11+.113*math.cos(ang),-.015+.113*math.sin(ang),z),(.041,.034,.045),'gold2',b=0)
leaf('Corn husk',(0,-.07,.41),(.20,-.06,.69),.10,'leaflight',.03)
for i in range(3):beam('Tassel',(0,0,.89),((i-1)*.065,0,1.06-abs(i-1)*.025),.02,col='straw',b=0)
close('corn',normalize=1)

# Crate: broad joinery and open gaps instead of a solid cube.
for i in range(4):box('Crate floor board',(-.36+i*.24,0,.075),(.22,.72,.10),'woodwarm',b=.018)
for x in [-.47,.47]:
 for y in [-.35,.35]:box('Crate corner post',(x,y,.33),(.10,.10,.59),'woodlight',b=.02)
for z in [.23,.46]:
 for y in [-.38,.38]:box('Open crate long plank',(0,y,z),(.99,.08,.16),'woodwarm',b=.022)
 for x in [-.49,.49]:box('Open crate short plank',(x,0,z),(.08,.78,.16),'woodlight',b=.02)
close('crate')

# A welcoming small farmhouse with bowed teal roof, shaped timber and a deep arched doorway.
box('Rough fieldstone step',(0,-.05,.13),(3.03,2.59,.26),'stone',b=.12)
box('Warm foundation',(0,0,.32),(2.86,2.42,.21),'cream',b=.08)
box('Apricot plaster walls',(0,0,1.43),(2.66,2.20,2.06),'peach',b=.15,seg=3)
# Solid gable infill keeps the roof physically attached at every slope.
roof('Upper gable',[(-1.32,2.42),(0,3.46),(1.32,2.42)],2.13,'plaster',thick=.94)
profile=[(-1.73,2.51),(-1.45,2.57),(-.83,3.16),(0,3.60),(.85,3.16),(1.45,2.57),(1.73,2.51)]
roof('Curved teal roof',profile,2.73,'roof',thick=.17)
for y in [-1.405,1.405]:
 for i in range(len(profile)-1):beam('Swept cream bargeboard',(profile[i][0],y,profile[i][1]-.05),(profile[i+1][0],y,profile[i+1][1]-.05),.145,.11,'ivory',.024)
# Roof seams and overlapping rounded shingles follow the actual roof profile.
for yy in [-.93,-.47,0,.47,.93]:
 for side in [-1,1]:
  beam('Raised roof seam',(0,yy,3.63),(side*.85,yy,3.19),.055,.040,'rooflight',.012)
  beam('Lower roof seam',(side*.85,yy,3.19),(side*1.62,yy,2.57),.05,.038,'rooflight',.01)
for x in [-1.30,1.30]:box('Corner timber post',(x,-1.085,1.42),(.18,.18,2.13),'woodwarm',b=.042)
for z in [.65,.99]:box('Lower weatherboard course',(0,-1.115,z),(2.67,.055,.20),'plaster',b=.019)
arch('Deep arched entrance',(0,-1.145,.41),.96,1.17,'dark',.10)
arch('Ivory door surround',(0,-1.237,.39),1.19,1.19,'ivory',.17,trim=.105)
for i in [-1,0,1]:
 x=i*.27;h=1.15+math.sqrt(max(0,.43*.43-x*x));box('Rounded door plank',(x,-1.22,.43+h/2),(.26,.08,h),'woodwarm' if i==0 else 'woodlight',b=.025)
box('Dark threshold',(0,-1.34,.405),(1.06,.38,.15),'wood',b=.045)
cyl('Round brass latch',(.25,-1.286,1.13),.062,.04,'gold2',n=12,rot=(math.pi/2,0,0),b=.009)
# Glazed side/front window with chunky teal shutters.
for x in [-.92,.92]:
 box('Window timber surround',(x,-1.155,1.73),(.48,.12,.67),'ivory',b=.060)
 box('Inset blue glass',(x,-1.227,1.74),(.35,.03,.52),'glass',b=.022,gloss=True)
 box('Window vertical mullion',(x,-1.25,1.74),(.035,.04,.53),'cream',b=.008)
 box('Window crossbar',(x,-1.25,1.74),(.37,.04,.036),'cream',b=.008)
 box('Warm sill',(x,-1.255,1.38),(.55,.26,.10),'woodwarm',b=.035)
 box('Glass diagonal glint',(x-.072,-1.252,1.90),(.09,.018,.045),'sky',b=.012,gloss=True)
# A round attic window is a different scale from the doorway and wall windows.
cyl('Attic window cream ring',(0,-1.393,2.84),.265,.09,'ivory',n=20,rot=(math.pi/2,0,0),b=.018)
cyl('Attic window glass',(0,-1.448,2.84),.19,.026,'glass',n=20,rot=(math.pi/2,0,0))
box('Attic window cross',(0,-1.473,2.84),(.36,.02,.033),'cream',b=.006)
box('Attic window upright',(0,-1.473,2.84),(.033,.02,.36),'cream',b=.006)
# Chimney and tiny side lean-to give the silhouette asymmetry.
box('Cream chimney',(1.00,.48,3.16),(.42,.44,1.16),'cream',b=.055)
for z in [2.92,3.24,3.55]:box('Chimney brick lip',(1,.48,z),(.45,.48,.10),'plaster',b=.02)
box('Chimney cap',(1,.48,3.77),(.58,.58,.16),'ivory',b=.046)
box('Chimney opening',(1,.48,3.854),(.33,.31,.014),'dark',b=.016)
box('Side rain barrel',(1.61,.65,.64),(.52,.60,.92),'woodlight',b=.13,seg=3)
for z in [.34,.79]:box('Barrel dark band',(1.61,.65,z),(.55,.63,.07),'roofdark',b=.028)
close('farmhouse')

# Striped market canvas: a curved canopy, scalloped edge, thick timber trestles and produce bins.
for x in [-1.28,1.28]:
 for y in [-.57,.57]:box('Market upright',(x,y,1.14),(.13,.15,2.24),'woodlight',b=.030)
box('Market counter',(0,-.02,.81),(2.89,1.32,.20),'woodwarm',b=.055)
for i in range(6):box('Counter front plank',(-1.16+i*.464,-.63,.44),(.44,.085,.60),'woodlight' if i%2 else 'woodwarm',b=.025)
for x in [-1.28,1.28]:beam('Market cross brace',(x,-.57,.2),(x,.57,.76),.075,col='wood',b=.017)
# Individual broad stripes share one vertex-color material; curved surface is real mesh.
for i in range(8):
 x=-1.50+i*.375;prof=[(-.87,1.89),(-.74,1.97),(-.35,2.34),(.14,2.54),(.70,2.30)]
 n=len(prof);v=[(xx,y,z) for xx in [x,x+.383] for y,z in prof];f=[(j,n+j,n+j+1,j+1) for j in range(n-1)];me=bpy.data.meshes.new('Canvas stripe');me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new('Canvas stripe',me);scene.collection.objects.link(o);finish(o,'Cream and persimmon canopy','ivory' if i%2 else 'plaster',smooth=True)
 box('Scalloped canvas hem',(x+.19,-.867,1.83),(.385,.06,.24),'ivory' if i%2 else 'plaster',b=.09,seg=3)
beam('Front awning bar',(-1.58,-.83,1.95),(1.58,-.83,1.95),.075,col='wood',b=.018)
beam('Rear awning ridge',(-1.57,.18,2.48),(1.57,.18,2.48),.09,col='woodlight',b=.024)
for k in range(3):
 x=-.94+k*.94;box('Produce tray',(x,-.24,.99),(.85,.84,.18),'wood',b=.025)
 for dx in [-.42,.42]:box('Tray raised edge',(x+dx,-.24,1.08),(.06,.85,.20),'woodwarm',b=.016)
 for j in range(3):
  for row in range(2):
   col=['orange','red','gold'][k];sphere('Market produce',(x+(j-1)*.22,-.41+row*.28,1.13),(.13,.15,.16),col,segments=10,rings=5)
# Wooden hanging sun emblem, no text or copied brand mark.
for x in [-.24,.24]:beam('Hanging sign cord',(x,-.88,1.94),(x,-.9,1.57),.02,col='wood',b=0)
box('Rounded hanging shop sign',(0,-.915,1.52),(.89,.085,.38),'cream',b=.10,seg=3)
cyl('Sun emblem',(0,-.967,1.54),.112,.028,'gold',n=12,rot=(math.pi/2,0,0))
for i in range(8):
 th=i*math.tau/8;beam('Sun ray',(.14*math.cos(th),-.97,1.54+.14*math.sin(th)),(.18*math.cos(th),-.97,1.54+.18*math.sin(th)),.018,col='gold2',b=0)
close('market-stall')

# Cart with curved handles and open planked body. Front = -Y authoring / +Z in glTF.
for i in range(5):box('Cart bed plank',(-.46+i*.23,.05,.52),(.21,1.29,.10),'woodwarm',b=.018)
for x in [-.61,.61]:
 for y in [-.54,.67]:box('Cart corner brace',(x,y,.78),(.10,.11,.68),'woodlight',b=.025)
 for z in [.73,.99]:box('Cart sideboard',(x,.04,z),(.095,1.39,.22),'woodwarm',b=.035)
for y in [-.59,.71]:
 for z in [.72,.98]:box('Cart endboard',(0,y,z),(1.27,.09,.21),'woodlight',b=.026)
for y in [-.40,.50]:
 beam('Cart iron axle',(-.80,y,.34),(.80,y,.34),.075,col='metal',b=.015)
 for x in [-.74,.74]:
  cyl('Dark rounded wheel',(x,y,.34),.32,.14,'wood',n=16,rot=(0,math.pi/2,0),b=.024)
  cyl('Wheel warm hub',(x+(-.076 if x<0 else .076),y,.34),.09,.04,'woodwarm',n=12,rot=(0,math.pi/2,0),b=.012)
  for i in range(6):
   th=i*math.tau/6;beam('Visible wheel spoke',(x+(-.079 if x<0 else .079),y,.34),(x+(-.079 if x<0 else .079),y+.26*math.cos(th),.34+.26*math.sin(th)),.040,col='woodwarm',b=.010)
for x in [-.43,.43]:
 beam('Swept tow arm',(x,-.49,.51),(x,-1.16,.50),.075,col='woodlight',b=.024)
 beam('Raised handle',(x,-1.16,.50),(x,-1.51,.69),.075,col='woodlight',b=.024)
beam('Cart handle grip',(-.45,-1.51,.69),(.45,-1.51,.69),.092,col='roof',b=.025)
close('cart')

# A small practical windmill, with an individually pivoted rotor exported as its own node.
lathe('Windmill stone footing',[(0,.95),(.18,.95),(.29,.82),(.34,.80)],col='stone2',n=16)
lathe('Tapered buttercream mill',[(.23,.75),(.45,.74),(1.75,.59),(2.66,.48),(2.88,.40)],col='cream',n=16)
for z in [.60,1.15,1.72]:cyl('Wood mill belt',(0,0,z),.73-(z-.45)*.11,.10,'woodlight',n=16,b=.018)
lathe('Teal mill cap',[(2.71,.66),(2.81,.64),(3.11,.39),(3.29,.025)],col='roof',n=16)
cyl('Rounded roof finial',(0,0,3.32),.09,.13,'gold2',n=12,b=.020)
arch('Mill shadowed doorway',(0,-.733,.28),.62,.92,'dark',.05)
arch('Mill timber doorway frame',(0,-.77,.27),.79,.93,'woodwarm',.08,trim=.085)
for i in [-1,0,1]:box('Mill door planks',(i*.17,-.797,.78),(.16,.04,.94),'woodlight',b=.018)
cyl('Mill rotor shaft',(0,-.67,2.67),.14,.50,'wood',n=12,rot=(math.pi/2,0,0),b=.020)
# Sail meshes have object coordinates at the rotor's pivot and rotate around local glTF Z.
for i in range(4):
 th=math.pi/4+i*math.pi/2
 def pt(r,t=0):return (math.cos(th)*r-math.sin(th)*t,-.86,2.67+math.sin(th)*r+math.cos(th)*t)
 beam('Rotor radial beam',pt(.04),pt(1.30),.10,.07,'woodwarm',.018,tag='rotor')
 for r in [.54,.78,1.02,1.25]:
  o=beam('Cream windmill sail',pt(r,-.14),pt(r,.20),.19,.045,'ivory',.025,tag='rotor')
 for t in [-.17,.23]:beam('Sail outside spar',pt(.39,t),pt(1.35,t),.035,.04,'woodlight',.012,tag='rotor')
cyl('Rotor round hub',(0,-.91,2.67),.205,.13,'rooflight',n=16,rot=(math.pi/2,0,0),b=.03,tag='rotor')
close('windmill',rotor=True)

# Mature apple tree, branching trunk and asymmetrical rounded foliage mass.
lathe('Flared orchard trunk',[(0,.28),(.15,.31),(.46,.20),(1.31,.14),(1.81,.07)],col='woodlight',n=10)
for end in [(-.47,.10,1.80),(.52,.11,1.73),(.02,-.41,2.12)]:beam('Visible orchard branch',(0,0,1.02),end,.12,col='woodlight',b=.035)
for xyz,s,col in [((-.43,.07,1.96),(.78,.70,.72),'leaf'),((.48,.03,2.08),(.76,.66,.78),'leaflight'),((0,.06,2.64),(.73,.66,.67),'leafsun'),((.01,-.43,2.29),(.65,.58,.62),'leaflight')]:sphere('Rounded orchard crown',xyz,s,col,segments=14,rings=8)
for i,(x,y,z) in enumerate([(-.74,-.37,1.94),(-.30,-.61,2.12),(.47,-.57,2.05),(.86,-.16,2.31),(.22,-.46,2.82),(-.39,-.42,2.75),(-.82,.25,2.38)]):
 sphere('Ripe red apple',(x,y,z),(.16,.15,.16),'redhi' if i%2 else 'red',segments=10,rings=5)
 beam('Apple stem',(x,y,z+.12),(x+.015,y,z+.23),.026,col='wood',b=0)
 leaf('Apple leaf',(x,y,z+.18),(x+.17,y+.01,z+.24),.043,'leafsun',.015)
close('apple-tree')
# Open cream timber fence segment; no fortress silhouette or solid border.
for x in [-.94,.94]:
 box('Rounded fence post',(x,0,.49),(.16,.20,.98),'ivory',b=.055,seg=3)
 sphere('Fence cap',(x,0,1.0),(.12,.13,.09),'cream',segments=10,rings=5)
for z in [.38,.74]:box('Fence horizontal rail',(0,.045,z),(1.95,.12,.13),'cream',b=.03)
beam('Fence diagonal brace',(-.82,-.024,.27),(.82,-.024,.84),.08,.065,'ivory',.022)
close('fence')

manifest={'title':'햇살 바구니 / Sunbasket Farm','artRevision':1,'provenance':'Original Blender meshes, hand-shaped from custom profiles, curved roof surfaces, leaves, arches and beveled timber. No downloaded geometry, textures, or game IP. No image-generation used.','axis':'glTF +Y up, +Z forward, y=0 ground. Crops normalized to height 1 and single primitive for instancing.','materials':'FARM_VERTEX_COLOR and WINDOW_VERTEX_COLOR use COLOR_0. Keep vertex colors. Windmill rotor has name windmill-rotor; rotate local Z, preserve initial position.','assets':{}}
for name,objs in assets.items():
 pts=[o.matrix_world@Vector(v) for o in objs for v in o.bound_box];lo=[min(p[i] for p in pts) for i in range(3)];hi=[max(p[i] for p in pts) for i in range(3)];tris=0
 for o in objs:o.data.calc_loop_triangles();tris+=len(o.data.loop_triangles)
 manifest['assets'][name]={'file':name+'.glb','bytes':os.path.getsize(ASSET+'/'+name+'.glb'),'triangles':tris,'drawCalls':len(objs),'gltfBounds':{'min':[lo[0],lo[2],-hi[1]],'max':[hi[0],hi[2],-lo[1]]}}
with open(ASSET+'/manifest.json','w') as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print('MODELS_READY '+json.dumps(manifest),flush=True)
# Save a model studio first so the builder can immediately start consuming assets.
orig=bpy.data.collections.new('Original export meshes');scene.collection.children.link(orig)
for objs in assets.values():
 for o in objs:
  for c in list(o.users_collection):c.objects.unlink(o)
  orig.objects.link(o);o.hide_render=True;o.hide_set(True)

def show(name,pos,scale=1,angle=0):
 root=bpy.data.objects.new('Display '+name,None);scene.collection.objects.link(root);root.location=pos;root.scale=(scale,scale,scale);root.rotation_euler.z=angle
 for src in assets[name]:
  o=src.copy();o.data=src.data;scene.collection.objects.link(o);o.hide_render=False;o.hide_set(False);o.parent=root
 return root
# The same orchard used in-game: an open farm, not a rectangular board enclosed by walls.
parts=[]
sphere('Rolling meadow',(0,0,-.53),(9.6,9.0,.65),'grass',segments=64,rings=16)
sphere('Meadow shoulder',(-5,3,-.25),(4,3,.62),'grasslight',segments=32,rings=10)
box('Rich soft earth bed',(-.25,-.55,.16),(5.7,4.7,.28),'soil',b=.24,seg=3)
for ix in range(7):
 x=-2.60+ix*.77
 for iy in range(5):
  y=-2.33+iy*.86
  name='carrot' if ix<3 else ('strawberry' if ix<5 else 'corn')
  show(name,(x,y,.30),.70,.15*math.sin(ix+iy))
# A warm curved lane is laid as overlapping ellipsoids, with irregular stepping stones.
for x,y,s in [(-3.95,-3.30,1.3),(-2.2,-3.78,1.3),(-.2,-4.1,1.5),(2.0,-3.83,1.4),(3.8,-2.65,1.25),(4.35,-.75,1.20),(4.2,1.08,1.2)]:sphere('Soft ochre footpath',(x,y,.06),(s,.73,.065),'straw',segments=24,rings=8)
show('farmhouse',(-4.12,3.14,.07),1.15,.10)
show('windmill',(3.53,4.06,.06),1.13,-.07)
show('market-stall',(4.20,-2.74,.09),1.1,-.17)
show('cart',(.34,-4.05,.1),1.08,.85)
show('crate',(.20,-3.78,.70),.71,.85)
for xyz,sc in [((-6.2,-.65,.04),1.06),((-6.4,2.27,.04),.91),((-.58,5.63,.04),1.10),((1.18,6.25,.04),.88),((6.15,1.6,.04),1.04)]:show('apple-tree',xyz,sc)
for x,y,angle in [(-6.6,-2.5,.18),(-5.8,-4.6,.28),(6.9,-.2,0),(6.75,2.03,0),(-2.0,6.4,math.pi/2)]:show('fence',(x,y,.07),1,angle)
for xyz,sc,ang in [((3.28,-1.2,.12),.8,0),((4.28,-.9,.12),.7,.13),((-5.0,1.45,.1),.70,.15)]:show('crate',xyz,sc,ang)
# A few broad leaves and flowers soften the meadow edge without crowding the farm.
for i in range(22):
 th=random.random()*math.tau;r=random.uniform(6.8,8.4);x=math.cos(th)*r;y=math.sin(th)*r
 for k in range(3):leaf('Meadow clover',(x,y,.09),(x+.23*math.cos(k*2.1),y+.23*math.sin(k*2.1),.31),.065,'leaflight',.04)
 if i%3==0:
  for k in range(5):sphere('Meadow flower petal',(x+.07*math.cos(k*math.tau/5),y+.07*math.sin(k*math.tau/5),.34),(.07,.045,.023),'ivory',segments=8,rings=4)
  sphere('Meadow flower center',(x,y,.36),(.047,.047,.02),'gold',segments=8,rings=4)
# Sunlit cream studio backdrop and large soft sources.
box('Warm infinite backdrop',(0,0,-.82),(200,200,.1),(.83,.77,.57),b=0)
world=bpy.data.worlds.new('Buttercream sky');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.57,.70,.62,1);world.node_tree.nodes['Background'].inputs[1].default_value=.42

def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
def light(name,pos,power,size,col):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size;d.color=col;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=pos;aim(o,(0,0,0))
light('Golden afternoon key',(-9,-8,16),2600,8,(1,.87,.62));light('Soft orchard bounce',(9,-3,10),1400,9,(.62,.87,.94));light('Warm leaf rim',(1,9,12),1700,8,(1,.94,.69))
d=bpy.data.cameras.new('Sunbasket cover');cam=bpy.data.objects.new('Sunbasket cover',d);scene.collection.objects.link(cam);cam.location=(11,-18,15);aim(cam,(0,.55,2.3));d.type='ORTHO';d.ortho_scale=32.3;scene.camera=cam
scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=True;scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
font=bpy.data.fonts.load(a.font_path) if os.path.exists(a.font_path) else bpy.data.fonts.get('Bfont')
def title(name,text,size,position,color):
 cu=bpy.data.curves.new(name,'FONT');cu.body=text;cu.font=font;cu.align_x='CENTER';cu.size=size;cu.offset=.028;cu.extrude=.004;cu.bevel_depth=.002;cu.bevel_resolution=1;o=bpy.data.objects.new(name,cu);scene.collection.objects.link(o);o.parent=cam;o.location=position;m=bpy.data.materials.new(name+' ink');m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Emission Color'].default_value=(*color,1);bs.inputs['Emission Strength'].default_value=.7;cu.materials.append(m);return o
sign=bpy.data.objects.new('Sunbasket wooden sign',None);scene.collection.objects.link(sign);sign.parent=cam;sign.location=(0,6.83,-13.12)
for nm,size,col,zz in [('Warm rounded wooden surround',(12.45,2.42,.18),'woodlight',0),('Cream painted sign face',(12.06,2.09,.09),'ivory',.13)]:
 o=box(nm,(0,0,0),size,col,b=.21,seg=3);o.parent=sign;o.location=(0,0,zz)
for xx in [-5.86,5.86]:
 for yy in [-.76,.76]:
  o=sphere('Sign wooden peg',(0,0,0),(.085,.085,.04),'wood',segments=10,rings=5);o.parent=sign;o.location=(xx,yy,.21)
# A simple sun mark recalls the produce-market emblem in the actual farm.
for i in range(8):
 th=i*math.tau/8;o=box('Sign sun ray',(0,0,0),(.09,.22,.035),'gold2',b=.03);o.parent=sign;o.location=(-5.02+.52*math.cos(th),.0+.52*math.sin(th),.23);o.rotation_euler=(0,0,th-math.pi/2)
o=cyl('Sign sun',(0,0,0),.34,.05,'gold',n=20,b=.015);o.parent=sign;o.location=(-5.02,0,.24)
head=title('햇살 바구니 로고','햇살 바구니',2.30,(.55,6.09,-12.82),(.15,.062,.024));tag=title('밭에서 가게까지','밭에서 가게까지',.49,(0,5.17,-12.80),(.25,.14,.049))
scene.render.resolution_x=1200;scene.render.resolution_y=630;scene.render.filepath=GAME+'/thumb.png'
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/sunbasket-farm-assets.blend',compress=True)
bpy.ops.render.render(write_still=True)
cam.location=(10,-18,17);aim(cam,(0,.6,.6));d.ortho_scale=22.6;sign.location=(0,9.52,-13.12);head.location=(.55,8.87,-12.82);head.data.size=2.20;tag.location=(0,7.95,-12.80);tag.data.size=.44
scene.render.resolution_x=1080;scene.render.resolution_y=1080;scene.render.filepath=GAME+'/square.png';bpy.ops.render.render(write_still=True)
for obj in list(scene.objects):
 if obj.type=='FONT':
  bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj;bpy.ops.object.convert(target='MESH')
for f in list(bpy.data.fonts):
 if f.users==0 and f.filepath:bpy.data.fonts.remove(f)
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/sunbasket-farm-assets.blend',compress=True)
print('SUNBASKET_RENDER_DONE',flush=True)

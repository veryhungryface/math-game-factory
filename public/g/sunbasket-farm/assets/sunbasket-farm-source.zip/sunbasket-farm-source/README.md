# 햇살 바구니 — original farm model source

Ten original Blender models used by the actual Three.js game, plus the exact farm cover scene, the self-contained procedural generator and supplementary logo/icon renderer. Original profiles, leaves, arches, timber, joinery, canopies and crop shapes; no downloaded meshes, textures, game characters or trademarks.

## Open and regenerate

Open `sunbasket-farm-assets.blend` in Blender 5.2 or newer. The visible farm is the cover scene. The hidden `Original export meshes` collection contains origin-aligned game models. The cover lettering is stored as mesh geometry, so viewing this blend requires no external fonts or textures.

```sh
blender --background --python generate_assets.py -- --output-dir ./generated-game --source-dir ./regenerated-source --font-path /path/to/Korean-font.ttf
blender --background --python render_details.py -- --source ./regenerated-source/sunbasket-farm-assets.blend --output-dir ./generated-game/assets --preview-dir ./previews --font-path /path/to/Korean-font.ttf
```

The first command produces the ten GLBs and both cover PNGs. The second renders the exact crop meshes into three transparent 192×192 icons and creates the transparent 1200×300 title sign. It also produces two studio previews. `--logo-only` renders just the title sign. The UI sign uses unlit painted colors to avoid distracting specular highlights on text; game objects and studio/covers use normal shaded materials.

Both scripts use only Blender's own Python API and standard Python modules. On macOS the font argument defaults to the installed Apple SD Gothic Neo font. Supply a legally available Korean font on other platforms. No system font is redistributed. Run these commands in a background Blender process; they do not modify a user's open interactive Blender session.

## Runtime contract

All models use glTF +Y up, +Z forward and y=0 ground. All colors are in `COLOR_0`: preserve `vertexColors` on `FARM_VERTEX_COLOR` and `WINDOW_VERTEX_COLOR`. There are no textures, skins or pre-baked animation tracks.

- `carrot.glb`: 192 triangles, one mesh/primitive, height 1.0.
- `strawberry.glb`: 456 triangles, one mesh/primitive, height 1.0, width 0.95.
- `corn.glb`: 344 triangles, one mesh/primitive, height 1.0.
- Crops have identity root transforms and are ready for InstancedMesh. A whole crop mesh is one game grid-cell marker; the decorative berries or leaves inside it do not mean multiple cells or boxes.
- `farmhouse.glb`: bowed teal roof, cream fascia, inset arched wooden doorway, glazed windows, chimney and rain barrel. Main color mesh plus one window material.
- `market-stall.glb`: curved striped awning, scalloped hem, trestle posts, produce bins and original sun sign. One mesh/primitive.
- `cart.glb`: open wooden boards, wheels/spokes and curved handles. +Z is the forward direction. One mesh/primitive.
- `windmill.glb`: static body plus `windmill-rotor`. Rotate that node about local Z, preserve its glTF translation `[0, 2.67, 0.86]`.
- `apple-tree.glb`, `fence.glb`, `crate.glb`: single meshes/primitives. Exact bounds, triangle counts and hashes are in `manifest.json`.

## Provenance and verification

Created in Blender 5.2.1 LTS, locally via background CLI. No image-generation/API calls were used for this game; all supplied raster images are renders of its actual source geometry. Colors/shapes translate the broad readability and warm farm atmosphere of the benchmark without reproducing its artwork.

The generated GLB structure, mesh primitive counts, crop triangle budgets and dimensions, vertex colors, ground alignment, windmill pivot, cover/icon/logo sizes and transparency were checked. ZIP contents were compared byte-for-byte with the final game assets. The runtime's local Three.js utilities keep their upstream MIT license in assets/lib/LICENSE; they are not required by these Blender scripts.

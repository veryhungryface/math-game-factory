import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {createDay,isCorrect,sampleProblems,CROPS,POOL} from './math.mjs';
import {decorateMeadow,decorateBuildings} from './assets/farm-polish.mjs?v=3';
import {carrotGrowth,CARROT_STAGE_HEIGHTS} from './assets/crop-growth.mjs?v=3';

const $=id=>document.getElementById(id);
const CELL=.7, BACK=-4.2, HANDLE_OFFSET=1.2, SAVE_KEY='sunbasket-farm-v1';
const STAGE_NAMES=['작은 텃밭','꽃피는 가게','풍성한 과수원','햇살 장터'];
const CROP_HEIGHT={carrot:.56,strawberry:.48,corn:.72};
let saved={wins:0,best:0,growth:0,coins:0},storageAvailable=true;
try{const s=JSON.parse(localStorage.getItem(SAVE_KEY)||'{}');for(const [key,max]of[['wins',9999],['best',2000],['growth',3],['coins',999999]])saved[key]=Math.max(0,Math.min(max,Math.floor(Number(s[key])||0)));}catch{storageAvailable=false;}
let ready=false,phase='loading',day=createDay(),round=0,height=2,score=0,coins=0,lives=3,solved=0;
let attempts=0,allAttempts=0,firstTry=0,firstAttempts=0,harvested=new Set(),growTime=0,deliveryTime=0;
let frames=0,inputCount=0,worldTime=0,startedAt=0,duration=0,farmStage=saved.growth,paused=false;
let guiding=true,dragId=null,brushId=null,lastBrush=null,holdDelay=null,holdRepeat=null;
let soundOn=false,audioContext=null,lastTone=0;
const order=()=>day[round];

// The farm is a real scene. All interactive crop positions are projected from these meshes.
const renderer=new THREE.WebGLRenderer({canvas:$('farm-canvas'),antialias:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
const scene=new THREE.Scene();scene.background=new THREE.Color(0xa9c997);scene.fog=new THREE.Fog(0xa9c997,32,72);
const camera=new THREE.OrthographicCamera(-8,8,10,-10,.1,100);camera.position.set(11,18,17);camera.lookAt(0,0,-.3);let cameraBlend=0;
function updateCamera(){const zoom=Math.max(1,Math.min(2.2,Math.sqrt(64/order().targetBoxes)));const offset=zoom>1?BACK+height*CELL/2+.3:0;camera.zoom=1+(zoom-1)*cameraBlend;camera.position.set(11,18,17+offset*cameraBlend);camera.lookAt(0,0,-.3+offset*cameraBlend);camera.updateProjectionMatrix();}
scene.add(new THREE.HemisphereLight(0xeaf6de,0x789169,1.28));
const sun=new THREE.DirectionalLight(0xffe9c9,1.94);sun.position.set(-9,18,9);sun.castShadow=true;sun.shadow.mapSize.set(1536,1536);sun.shadow.radius=3.5;sun.shadow.normalBias=.025;sun.shadow.bias=-.0008;Object.assign(sun.shadow.camera,{left:-17,right:17,top:18,bottom:-18,near:1,far:45});scene.add(sun);
const fill=new THREE.DirectionalLight(0xb7e3df,.75);fill.position.set(11,8,-10);scene.add(fill);
const mat=(color,roughness=.9)=>new THREE.MeshStandardMaterial({color,roughness});
const grassMat=mat(0xc6dfac),soilMat=mat(0xa97143),woodMat=mat(0xb68145),trimMat=mat(0xe9c28b);

function grassTexture(){const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.fillStyle='#8cb16b';g.fillRect(0,0,256,256);let seed=92;const rand=()=>((seed=seed*16807%2147483647)/2147483647);for(let i=0;i<3600;i++){g.fillStyle=i%3?'#d9dd8418':'#54774614';g.fillRect(rand()*256,rand()*256,1,2+rand()*2);}const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(12,12);t.anisotropy=4;return t;}
grassMat.map=grassTexture();
function mesh(geometry,material,x=0,y=0,z=0,shadow=true){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=shadow;m.receiveShadow=true;scene.add(m);return m;}
const ground=mesh(new THREE.PlaneGeometry(110,110),grassMat,0,-.09,0,false);ground.rotation.x=-Math.PI/2;
const organicGround=mesh(new THREE.CylinderGeometry(8.2,8.7,.34,12),mat(0x9fb875),0,-.22,0,false);organicGround.scale.set(1.25,1,1.16);organicGround.visible=false;
const gardenBase=mesh(new THREE.BoxGeometry(8.7,.1,8.7),mat(0xb9aa72),0,-.03,0,false);
const dormantSoil=mesh(new THREE.BoxGeometry(8.4,.035,8.4),mat(0xc5b783),0,.03,0,false);gardenBase.visible=false;dormantSoil.visible=false;

// The reusable landscape owns paths, planting islands and distant terrain.
const environment=decorateMeadow(scene);

// The logical 1 m² cells stay exact. Only currently selected rows receive tilled soil.
const soilTiles=new THREE.InstancedMesh(new THREE.BoxGeometry(CELL-.025,.065,CELL-.025),soilMat,144);soilTiles.receiveShadow=true;scene.add(soilTiles);
const previewTiles=new THREE.InstancedMesh(new THREE.BoxGeometry(CELL-.025,.065,CELL-.025),soilMat,72);previewTiles.receiveShadow=true;scene.add(previewTiles);
const furrows=new THREE.InstancedMesh(new THREE.BoxGeometry(CELL*.76,.018,.035),mat(0x9e683f),144*3);furrows.receiveShadow=true;scene.add(furrows);
const frameEdges=Array.from({length:4},()=>mesh(new THREE.BoxGeometry(1,.105,.1),woodMat));
const cornerStakes=Array.from({length:4},()=>mesh(new THREE.CylinderGeometry(.055,.065,.35,7),trimMat));
const widthMeasure=mesh(new THREE.BoxGeometry(1,.025,.025),mat(0xffefc0),0,.19,0,false);
const heightMeasure=mesh(new THREE.BoxGeometry(.025,.025,1),mat(0xffefc0),0,.19,0,false);const handleLead=mesh(new THREE.BoxGeometry(.06,.05,HANDLE_OFFSET),trimMat,0,.14,0,false);
const dummy=new THREE.Object3D(),matrix=new THREE.Matrix4(),templates={},cropInstances={},carrotStageInstances={};
const growthGroups=[new THREE.Group(),new THREE.Group(),new THREE.Group()];growthGroups.forEach(g=>scene.add(g));
let cart=null,market=null,windRotor=null,crateInstances=[],viewport={x:0,y:0,w:1,h:1,reserved:90,renderH:1};
const CART_HOME=new THREE.Vector3(5.35,0,5.35),CART_END=new THREE.Vector3(.2,0,7.25);
const sproutGeo=new THREE.ConeGeometry(.1,.32,5),sprouts=new THREE.InstancedMesh(sproutGeo,mat(0x6fa957),288);scene.add(sprouts);

function model(name,wantedHeight,position,rotation=0,parent=scene){const root=templates[name].clone(true),bounds=new THREE.Box3().setFromObject(root),size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3()),s=wantedHeight/size.y;root.scale.setScalar(s);root.position.set(-center.x*s,-bounds.min.y*s,-center.z*s);root.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});const group=new THREE.Group();group.add(root);group.position.copy(position);group.rotation.y=rotation;parent.add(group);return group;}
function makeInstances(name,max,wantedHeight,parent=scene){const root=templates[name];root.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(root),size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3());const normalize=new THREE.Matrix4().makeScale(wantedHeight/size.y,wantedHeight/size.y,wantedHeight/size.y);normalize.multiply(new THREE.Matrix4().makeTranslation(-center.x,-bounds.min.y,-center.z));const out=[];root.traverse(o=>{if(!o.isMesh)return;const m=new THREE.InstancedMesh(o.geometry,o.material,max);m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);m.castShadow=true;m.receiveShadow=true;m.frustumCulled=false;m.count=0;parent.add(m);out.push({mesh:m,local:new THREE.Matrix4().multiplyMatrices(normalize,o.matrixWorld)});});return out;}
function applyInstance(pieces,index,rootMatrix){for(const p of pieces){matrix.multiplyMatrices(rootMatrix,p.local);p.mesh.setMatrixAt(index,matrix);}}
function cellPosition(index,h=height){const col=index%order().width,row=Math.floor(index/order().width);return{x:(col+.5-order().width/2)*CELL,y:.1,z:BACK+(row+.5)*CELL,row,col};}

function projectWorld(x,y,z){const v=new THREE.Vector3(x,y,z).project(camera);return{x:viewport.x+(v.x+1)*viewport.w/2,y:viewport.y+viewport.reserved+(1-v.y)*viewport.renderH/2};}
function localPlacement(el,x,y,z){const p=projectWorld(x,y,z);el.style.left=(p.x-viewport.x)+'px';el.style.top=(p.y-viewport.y)+'px';return p;}
function placeLabels(){if(!ready)return;const w=order().width*CELL,front=BACK+height*CELL;const handle=localPlacement($('field-handle'),0,.17,front+HANDLE_OFFSET);localPlacement($('width-label'),0,.26,BACK-.9);localPlacement($('height-label'),w/2+1,.22,(BACK+front)/2);$('field-guide').style.left=Math.max(125,Math.min(viewport.w-125,handle.x-viewport.x))+'px';$('field-guide').style.top=Math.min(viewport.h-70,handle.y-viewport.y+83)+'px';}
function resize(){const r=$('world').getBoundingClientRect();if(!r.width||!r.height)return;const reserved=innerWidth>=900?115:99,renderH=Math.max(135,r.height-reserved);viewport={x:r.x,y:r.y,w:r.width,h:r.height,reserved,renderH};renderer.setSize(r.width,r.height,false);renderer.setViewport(0,0,r.width,renderH);const aspect=r.width/renderH,halfH=Math.max(innerWidth>=900?8.7:8.15,7.45/aspect);camera.left=-halfH*aspect;camera.right=halfH*aspect;camera.top=halfH;camera.bottom=-halfH;camera.updateProjectionMatrix();document.documentElement.classList.toggle('land',innerWidth>=900);placeLabels();}
new ResizeObserver(resize).observe($('world'));

function updatePlot(){const w=order().width*CELL,d=height*CELL,front=BACK+d;soilTiles.count=order().width*height;furrows.count=soilTiles.count*3;for(let i=0;i<soilTiles.count;i++){const c=cellPosition(i);dummy.position.set(c.x,.077,c.z);dummy.rotation.set(0,0,0);dummy.scale.setScalar(1);dummy.updateMatrix();soilTiles.setMatrixAt(i,dummy.matrix);for(let j=0;j<3;j++){dummy.position.set(c.x,.121,c.z+(j-1)*CELL*.22);dummy.updateMatrix();furrows.setMatrixAt(i*3+j,dummy.matrix);}}soilTiles.instanceMatrix.needsUpdate=true;furrows.instanceMatrix.needsUpdate=true;frameEdges[0].position.set(0,.14,BACK);frameEdges[1].position.set(0,.14,front);for(let i=0;i<2;i++){frameEdges[i].scale.set(w+.14,1,1);frameEdges[i].rotation.y=0;}for(let i=2;i<4;i++){frameEdges[i].position.set((i===2?-1:1)*w/2,.14,BACK+d/2);frameEdges[i].scale.set(d+.12,1,1);frameEdges[i].rotation.y=Math.PI/2;}for(let i=0;i<4;i++)cornerStakes[i].position.set((i%2?1:-1)*w/2,.17,i<2?BACK:front);widthMeasure.position.set(0,.2,BACK-.28);widthMeasure.scale.x=w;heightMeasure.position.set(w/2+.26,.2,BACK+d/2);heightMeasure.scale.z=d;handleLead.position.set(0,.14,front+HANDLE_OFFSET/2);$('height-readout').innerHTML=`${height}<small>m</small>`;$('width-label').innerHTML=`가로 <b>${order().width}m</b>`;$('height-label').innerHTML=`세로 <b>${height}m</b>`;$('field-handle').setAttribute('aria-label',`밭 세로 ${height}m. 끌어서 길이 조절`);placeLabels();}

function save(){try{localStorage.setItem(SAVE_KEY,JSON.stringify(saved));}catch{storageAvailable=false;}}
function updateGrowth(){farmStage=Math.max(saved.growth,Math.min(3,Math.floor(solved/3)));growthGroups.forEach((g,i)=>g.visible=i<farmStage);$('growth-name').textContent=STAGE_NAMES[farmStage];$('coins').innerHTML=`${coins}<small>코인</small>`;$('best-record').textContent=saved.best?`최고 기록 ${saved.best}점`:'최고 기록 —';$('day-record').textContent=`완주한 날 ${saved.wins}`;}
function setFeedback(title,text){$('feedback').replaceChildren();const b=document.createElement('b'),p=document.createElement('p');b.textContent=title;p.textContent=text;$('feedback').append(b,p);}
function setGuiding(value){guiding=value;document.body.dataset.guiding=String(value);}
function setPhase(value){phase=value;previewTiles.visible=value==='title';soilTiles.visible=value!=='title';furrows.visible=value!=='title';if(value==='playing'||value==='retry'||value==='title'){cameraBlend=0;updateCamera();}document.body.dataset.phase=value;const editable=value==='playing'||value==='retry';$('height-minus').disabled=!editable;$('height-plus').disabled=!editable;$('field-handle').hidden=!editable;handleLead.visible=editable;$('width-label').hidden=!['playing','retry'].includes(value);$('height-label').hidden=$('width-label').hidden;$('harvest-meter').hidden=value!=='harvest';$('field-guide').hidden=!editable;if(!editable)releaseInputs();}
function planning(){setPhase('playing');growTime=0;deliveryTime=0;harvested=new Set();$('world-toast').textContent='';$('plant').disabled=false;$('plant').innerHTML='심기 <span>↗</span>';$('tool-tip').textContent='밭 끝을 드래그 · ↑↓ 키로 1m씩';$('order-number').textContent=`주문 ${round+1} / 9`;$('order-request').innerHTML=`${CROPS[order().crop].name} <strong>${order().targetBoxes}</strong>상자`;$('crop-icon').innerHTML=`<img src="./assets/icon-${order().crop}.png?v=3" alt="">`;$('order-width').innerHTML=`${order().width}<small>m</small>`;$('day-progress').innerHTML=Array.from({length:9},(_,i)=>`<i class="${i<solved?'done':i===round?'active':''}"></i>`).join('');if(cart){cart.position.copy(CART_HOME);cart.rotation.y=-Math.PI/2;}updatePlot();updateCargo();updateGrowth();if(!attempts)setFeedback(order().tutorial?'첫 주문 · 당근 12상자를 키워요':`${CROPS[order().crop].name} 주문이 왔어요`,order().tutorial?'가로 4m인 밭의 세로를 정해 보세요.':'주문만큼 수확하도록 세로를 정한 뒤 심으세요.');}
function start(){if(!ready)return;unlockAudio();releaseInputs();$('intro').hidden=true;$('ending').hidden=true;day=createDay();round=0;height=2;score=0;coins=0;lives=3;solved=0;attempts=0;allAttempts=0;firstTry=0;firstAttempts=0;startedAt=performance.now();duration=0;$('hearts').textContent='♥♥♥';$('hearts').setAttribute('aria-label','기회 3번');setGuiding(true);planning();}
function setHeight(value,real=true){if(!['playing','retry'].includes(phase))return;const next=Math.max(1,Math.min(12,Math.round(Number(value))));if(!Number.isFinite(next))return;if(phase==='retry'){setPhase('playing');$('plant').innerHTML='다시 심기 <span>↗</span>';}if(next===height)return;height=next;if(real){inputCount++;setGuiding(false);}updatePlot();tone(240+height*22,.05,'triangle',.018);}
function plant(){if(!ready||!['playing','retry'].includes(phase))return;unlockAudio();releaseInputs();setGuiding(false);inputCount++;attempts++;allAttempts++;const correct=isCorrect(order(),height);if(attempts===1&&!order().tutorial){firstAttempts++;if(correct)firstTry++;}if(!correct){lives--;$('hearts').textContent='♥'.repeat(lives)+'♡'.repeat(3-lives);$('hearts').setAttribute('aria-label',`기회 ${lives}번`);const made=order().width*height,diff=Math.abs(made-order().targetBoxes);setFeedback(made<order().targetBoxes?'밭이 조금 더 필요해요':'밭이 너무 넓어요',`${order().width}m × ${height}m = ${made}m². 주문보다 ${diff}상자 ${made<order().targetBoxes?'부족해요':'많아요'}.`);tone(165,.18,'triangle',.025);if(lives<=0){finish(false);return;}setPhase('retry');$('plant').innerHTML='다시 심기 <span>↗</span>';setGuiding(true);return;}score+=order().tutorial?40:attempts===1?100:70;setPhase('growing');growTime=0;$('plant').disabled=true;$('plant').textContent='자라는 중…';$('world-toast').textContent='햇살 먹고 쑥쑥!';setFeedback('딱 맞는 밭이에요',`${order().width}m × ${height}m = ${order().targetBoxes}m². 작물이 자라고 있어요.`);tone(523,.1,'sine',.035);tone(659,.14,'sine',.03,.1);}
function beginHarvest(){if(phase!=='growing')return;setPhase('harvest');$('world-toast').textContent='밭을 쓸어 담아요';$('plant').disabled=false;$('plant').textContent='쓸어서 수확';$('tool-tip').textContent='밭을 드래그 · Space로 한 줄씩 수확';setFeedback('바구니를 채워 보세요',`${order().width}m × ${height}m = ${order().targetBoxes}m². 밭을 쓸어 수확해요.`);updateHarvestMeter();}
function updateHarvestMeter(){$('harvest-count').textContent=`${harvested.size} / ${order().targetBoxes}상자`;$('harvest-fill').style.width=harvested.size/order().targetBoxes*100+'%';}
function harvestCells(indices,real=true){if(phase!=='harvest')return;let changed=false;for(const index of indices){if(!Number.isInteger(index)||index<0||index>=order().targetBoxes||harvested.has(index))continue;harvested.add(index);changed=true;const c=cellPosition(index);flyCrop(c.x,.3,c.z,order().crop);}if(!changed)return;if(real)inputCount++;$('world-toast').textContent='';updateHarvestMeter();updateCargo();tone(440+(harvested.size%6)*70,.055,'triangle',.023);if(harvested.size===order().targetBoxes){setPhase('delivering');deliveryTime=-.35;$('plant').disabled=true;$('plant').textContent='가게로 출발!';$('world-toast').textContent='한 바구니 가득!';setFeedback('수레에 모두 실었어요',`${order().targetBoxes}상자를 가게로 보내고 있어요.`);}}
function harvestRow(){if(phase!=='harvest')return;let first=-1;for(let i=0;i<order().targetBoxes;i++)if(!harvested.has(i)){first=Math.floor(i/order().width);break;}if(first<0)return;harvestCells(Array.from({length:order().width},(_,i)=>first*order().width+i));}
function finishDelivery(){if(phase!=='delivering')return;solved++;coins+=order().targetBoxes;const nextGrowth=Math.min(3,Math.floor(solved/3)),grew=nextGrowth>farmStage;saved.growth=Math.max(saved.growth,nextGrowth);saved.coins+=order().targetBoxes;save();updateGrowth();setPhase('success');$('plant').disabled=false;$('plant').textContent=solved===9?'오늘의 수확 보기':'다음 주문 →';$('world-toast').textContent=grew?`${STAGE_NAMES[farmStage]}로 자랐어요!`:'납품 완료!';setFeedback(grew?'농장에 새 풍경이 생겼어요':'가게에 무사히 도착했어요',`${order().targetBoxes}상자 납품 · +${order().targetBoxes}코인${attempts===1?' · 첫 시도 성공!':''}`);$('day-progress').innerHTML=Array.from({length:9},(_,i)=>`<i class="${i<solved?'done':''}"></i>`).join('');tone(659,.12,'triangle',.025);tone(880,.18,'sine',.03,.13);}
function nextOrder(){if(phase!=='success')return;if(solved===9){finish(true);return;}round++;height=2;attempts=0;setGuiding(false);planning();}
function finish(won){setPhase(won?'won':'lost');duration=(performance.now()-startedAt)/1000;$('ending').hidden=false;$('ending-kicker').textContent=won?'아홉 주문, 모두 완성':'오늘은 여기까지';$('ending-title').innerHTML=won?'바구니 가득,<br>햇살 가득!':'밭을 다시 가꾸면<br>또 자라나요';$('ending-text').textContent=won?`${coins}상자 납품 · ${score}점\n첫 시도 성공 ${firstTry} / 8\n주문에 맞는 넓이를 스스로 만들었어요.`:`${solved} / 9 주문 납품\n넓이 ÷ 가로 = 세로를 떠올려 보세요.\n새로운 하루에는 기회가 다시 3번이에요.`;if(won){saved.wins++;saved.best=Math.max(saved.best,score);saved.growth=3;save();updateGrowth();$('ending-growth').textContent=storageAvailable?'햇살 장터 완성! 자란 농장은 다음에도 남아요.':'햇살 장터 완성! 이번 화면에서 자란 농장을 즐겨요.';}else $('ending-growth').textContent='가꾼 농장 장식은 그대로 남아 있어요.';}
function primaryAction(){if(phase==='playing'||phase==='retry')plant();else if(phase==='success')nextOrder();else if(phase==='harvest'){setFeedback('수확할 작물이 기다려요','밭 위를 손가락으로 쓸어 보세요. Space도 돼요.');$('world-toast').textContent='작물 위를 쓱쓱!';}}

// Pointer coordinates are transformed through the exact rendering viewport, never guessed.
const raycaster=new THREE.Raycaster(),groundPlane=new THREE.Plane(new THREE.Vector3(0,1,0),-.13),groundPoint=new THREE.Vector3();
function pointOnGround(clientX,clientY){raycaster.setFromCamera(new THREE.Vector2((clientX-viewport.x)/viewport.w*2-1,-((clientY-viewport.y-viewport.reserved)/viewport.renderH*2-1)),camera);return raycaster.ray.intersectPlane(groundPlane,groundPoint);}
function dragHandle(e){if(dragId!==e.pointerId)return;const p=pointOnGround(e.clientX,e.clientY);if(p)setHeight((p.z-BACK-HANDLE_OFFSET)/CELL);}
$('field-handle').addEventListener('pointerdown',e=>{if(!['playing','retry'].includes(phase))return;e.preventDefault();unlockAudio();dragId=e.pointerId;$('field-handle').setPointerCapture(e.pointerId);setGuiding(false);});
$('field-handle').addEventListener('pointermove',dragHandle);
for(const event of ['pointerup','pointercancel','lostpointercapture'])$('field-handle').addEventListener(event,()=>{dragId=null;});
function releaseInputs(){dragId=null;brushId=null;lastBrush=null;clearTimeout(holdDelay);clearInterval(holdRepeat);holdDelay=null;holdRepeat=null;$('brush-ring')?.setAttribute('hidden','');}
for(const [id,delta] of [['height-minus',-1],['height-plus',1]]){const el=$(id);el.addEventListener('pointerdown',e=>{if(!['playing','retry'].includes(phase))return;e.preventDefault();unlockAudio();releaseInputs();el.setPointerCapture(e.pointerId);setHeight(height+delta);holdDelay=setTimeout(()=>{holdRepeat=setInterval(()=>setHeight(height+delta),130);},390);});for(const event of ['pointerup','pointercancel','lostpointercapture'])el.addEventListener(event,()=>{clearTimeout(holdDelay);clearInterval(holdRepeat);});el.addEventListener('click',e=>{if(e.detail===0)setHeight(height+delta);});}
const brushRing=document.createElement('i');brushRing.id='brush-ring';brushRing.className='harvest-cursor';brushRing.hidden=true;brushRing.setAttribute('aria-hidden','true');$('world').append(brushRing);
const tapRing=document.createElement('i');tapRing.className='soft-tap';tapRing.hidden=true;tapRing.setAttribute('aria-hidden','true');$('world').append(tapRing);let tapTimer;
function showWorldHint(x,y){if(!['playing','retry'].includes(phase))return;setGuiding(true);if(phase!=='retry')setFeedback('밭 끝의 둥근 손잡이를 잡아 보세요','끌어서 세로를 바꾼 뒤 심으면 작물이 자라요.');tapRing.style.left=(x-viewport.x)+'px';tapRing.style.top=(y-viewport.y)+'px';tapRing.hidden=false;clearTimeout(tapTimer);for(const a of tapRing.getAnimations())a.cancel();tapRing.animate([{transform:'translate(-50%,-50%) scale(.5)',opacity:1},{transform:'translate(-50%,-50%) scale(2)',opacity:0}],{duration:650});tapTimer=setTimeout(()=>tapRing.hidden=true,650);}
function cropScreenPoints(){if(!['harvest','growing'].includes(phase))return[];const out=[];for(let i=0;i<order().targetBoxes;i++){if(harvested.has(i))continue;const c=cellPosition(i),p=projectWorld(c.x,.1+CROP_HEIGHT[order().crop]*.42,c.z);out.push({index:i,row:c.row,col:c.col,x:p.x,y:p.y});}return out;}
function sweepAt(x,y){if(phase!=='harvest')return;brushRing.hidden=false;brushRing.style.left=(x-viewport.x)+'px';brushRing.style.top=(y-viewport.y)+'px';const radius=innerWidth<900?29:34,selected=[];for(const c of cropScreenPoints()){let d=(c.x-x)**2+(c.y-y)**2;if(lastBrush){const vx=x-lastBrush.x,vy=y-lastBrush.y,length=vx*vx+vy*vy,t=length?Math.max(0,Math.min(1,((c.x-lastBrush.x)*vx+(c.y-lastBrush.y)*vy)/length)):0;d=Math.min(d,(c.x-lastBrush.x-vx*t)**2+(c.y-lastBrush.y-vy*t)**2);}if(d<=radius*radius)selected.push(c.index);}harvestCells(selected);lastBrush={x,y};}
$('farm-canvas').addEventListener('pointerdown',e=>{if(phase==='harvest'){e.preventDefault();unlockAudio();brushId=e.pointerId;lastBrush=null;$('farm-canvas').setPointerCapture(e.pointerId);sweepAt(e.clientX,e.clientY);}else showWorldHint(e.clientX,e.clientY);});
$('farm-canvas').addEventListener('pointermove',e=>{if(e.pointerId===brushId)sweepAt(e.clientX,e.clientY);});
for(const event of ['pointerup','pointercancel','lostpointercapture'])$('farm-canvas').addEventListener(event,()=>{brushId=null;lastBrush=null;brushRing.hidden=true;});
document.addEventListener('keydown',e=>{if(e.altKey||e.metaKey||e.ctrlKey)return;if(['ArrowUp','ArrowDown','ArrowRight','ArrowLeft'].includes(e.key)&&['playing','retry'].includes(phase)){e.preventDefault();setHeight(height+(['ArrowUp','ArrowRight'].includes(e.key)?1:-1));}if((e.key===' '||e.code==='Space')&&phase==='harvest'){e.preventDefault();if(!e.repeat)harvestRow();}else if(e.key==='Enter'&&e.target===document.body&&!e.repeat){e.preventDefault();if(phase==='title')start();else primaryAction();}});
window.addEventListener('blur',()=>{paused=true;releaseInputs();if(audioContext)audioContext.suspend().catch(()=>{});});
window.addEventListener('focus',()=>{paused=false;if(audioContext&&soundOn)audioContext.resume().catch(()=>{});});
document.addEventListener('visibilitychange',()=>{paused=document.hidden;releaseInputs();});
$('start').addEventListener('click',start);$('plant').addEventListener('click',primaryAction);$('restart').addEventListener('click',start);

function unlockAudio(){if(!soundOn)return;try{audioContext??=new(window.AudioContext||window.webkitAudioContext)();if(audioContext.state==='suspended')audioContext.resume().catch(()=>{});}catch{soundOn=false;}}
function tone(freq,duration=.08,type='sine',volume=.025,delay=0){if(!soundOn||!audioContext||paused)return;const now=audioContext.currentTime;if(delay===0&&now-lastTone<.035)return;lastTone=now;const oscillator=audioContext.createOscillator(),gain=audioContext.createGain(),at=now+delay;oscillator.type=type;oscillator.frequency.setValueAtTime(freq,at);gain.gain.setValueAtTime(volume,at);gain.gain.exponentialRampToValueAtTime(.0001,at+duration);oscillator.connect(gain).connect(audioContext.destination);oscillator.start(at);oscillator.stop(at+duration);}
$('sound').addEventListener('click',()=>{soundOn=!soundOn;unlockAudio();$('sound').innerHTML=`♪<small>${soundOn?'ON':'OFF'}</small>`;$('sound').setAttribute('aria-label',soundOn?'소리 끄기':'소리 켜기');if(soundOn){tone(1174,.09);tone(1568,.12,'sine',.025,.16);}});

const flyers=[];for(let i=0;i<16;i++){const m=mesh(new THREE.OctahedronGeometry(.14,0),mat(0xe5a054),0,0,0,false);m.visible=false;flyers.push({mesh:m,life:0,start:new THREE.Vector3()});}
function flyCrop(x,y,z,crop){const f=flyers.find(f=>f.life<=0);if(!f)return;f.life=.48;f.start.set(x,y,z);f.mesh.position.copy(f.start);f.mesh.material.color.set(CROPS[crop].color);f.mesh.visible=true;}
function updateCargo(){if(!crateInstances.length)return;const count=harvested.size;crateInstances.forEach(p=>p.mesh.count=count);for(let i=0;i<count;i++){dummy.position.set(-.43+(i%6)*.175,.66+Math.floor(i/36)*.135,-.42+(Math.floor(i/6)%6)*.155);dummy.rotation.set(0,0,0);dummy.scale.setScalar(1);dummy.updateMatrix();applyInstance(crateInstances,i,dummy.matrix);}crateInstances.forEach(p=>p.mesh.instanceMatrix.needsUpdate=true);}
function updateCrops(){
 if(!ready)return;
 for(const pieces of Object.values(carrotStageInstances))pieces.forEach(p=>p.mesh.count=0);
 if(phase==='title'){
  sprouts.count=0;
  for(const [block,key]of ['carrot','strawberry','corn'].entries()){
   const pieces=cropInstances[key];pieces.forEach(p=>p.mesh.count=24);
   for(let i=0;i<24;i++){dummy.position.set((i%8-3.5)*CELL,.105,BACK+(block*3+Math.floor(i/8)+.5)*CELL);dummy.rotation.set(0,Math.sin(i)*.1,Math.sin(worldTime+i)*.025);dummy.scale.setScalar(1);dummy.updateMatrix();applyInstance(pieces,i,dummy.matrix);}
   pieces.forEach(p=>p.mesh.instanceMatrix.needsUpdate=true);
  }
  return;
 }
 const active=['growing','harvest','delivering','success'].includes(phase),name=order().crop,stagedCarrots=phase==='growing'&&name==='carrot';
 for(const[key,pieces]of Object.entries(cropInstances))pieces.forEach(p=>p.mesh.count=active&&key===name?order().targetBoxes:0);
 sprouts.count=phase==='growing'&&!stagedCarrots?order().targetBoxes*2:0;
 if(!active)return;
 if(stagedCarrots)for(const pieces of Object.values(carrotStageInstances))pieces.forEach(p=>p.mesh.count=order().targetBoxes);
 const pieces=cropInstances[name];
 for(let i=0;i<order().targetBoxes;i++){
  const c=cellPosition(i);let scale=harvested.has(i)?.001:1,appearance=null;
  if(phase==='growing'){
   if(stagedCarrots){appearance=carrotGrowth(Math.max(0,growTime-(c.row%3)*.035));scale=appearance.stage==='carrot'?appearance.scale:.001;}
   else{const progress=Math.max(0,Math.min(1,(growTime-.22-(c.row%3)*.035)/.82));scale=progress<1?1-Math.pow(1-progress,3):1;}
  }
  dummy.position.set(c.x,.105,c.z);dummy.rotation.set(0,Math.sin(i*2.1)*.11,Math.sin(worldTime*1.4+i)*.025);dummy.scale.setScalar(scale);dummy.updateMatrix();applyInstance(pieces,i,dummy.matrix);
  if(stagedCarrots){for(const[stage,stagePieces]of Object.entries(carrotStageInstances)){dummy.scale.setScalar(appearance.stage===stage?appearance.scale:.001);dummy.updateMatrix();applyInstance(stagePieces,i,dummy.matrix);}}
  else if(phase==='growing'){
   const seedScale=Math.min(1,growTime*5)*Math.max(0,1-(growTime-.25)*2);
   for(let j=0;j<2;j++){dummy.position.set(c.x+(j?1:-1)*.065,.14+seedScale*.1,c.z);dummy.rotation.set(0,0,j?.7:-.7);dummy.scale.setScalar(seedScale);dummy.updateMatrix();sprouts.setMatrixAt(i*2+j,dummy.matrix);}
  }
 }
 pieces.forEach(p=>p.mesh.instanceMatrix.needsUpdate=true);
 if(stagedCarrots)for(const pieces of Object.values(carrotStageInstances))pieces.forEach(p=>p.mesh.instanceMatrix.needsUpdate=true);
 else if(phase==='growing')sprouts.instanceMatrix.needsUpdate=true;
}
let previous=performance.now(),lastBird=0;
function animate(now){requestAnimationFrame(animate);const dt=Math.min(.05,(now-previous)/1000);previous=now;if(paused)return;frames++;worldTime+=dt;if(phase==='growing'){growTime+=dt;if(growTime>.7)$('world-toast').textContent='';if(growTime>=1.14)beginHarvest();}else if(phase==='delivering'){deliveryTime+=dt;const t=Math.max(0,Math.min(1,deliveryTime/1.2)),smooth=t*t*(3-2*t);cart.position.lerpVectors(CART_HOME,CART_END,smooth);cart.position.y=Math.sin(t*Math.PI*10)*.025;cart.rotation.y=Math.atan2(CART_END.x-CART_HOME.x,CART_END.z-CART_HOME.z);if(deliveryTime>1.2)finishDelivery();}if(phase==='growing')cameraBlend=Math.min(1,growTime/1.14);else if(phase==='harvest')cameraBlend=1;else if(phase==='delivering')cameraBlend=1-Math.max(0,Math.min(1,deliveryTime/.85));else cameraBlend=0;updateCamera();if(windRotor)windRotor.rotation.z=worldTime*.23;updateCrops();for(const f of flyers){if(f.life<=0)continue;f.life-=dt;f.mesh.visible=f.life>0;const t=1-Math.max(0,f.life/.48);f.mesh.position.lerpVectors(f.start,CART_HOME,t);f.mesh.position.y=.3+Math.sin(t*Math.PI)*2.2;f.mesh.rotation.y+=dt*5;f.mesh.scale.setScalar(1-t*.55);}if(soundOn&&worldTime-lastBird>14&&['playing','harvest'].includes(phase)){lastBird=worldTime;tone(1568,.09,'sine',.007);tone(1760,.12,'sine',.006,.16);}renderer.render(scene,camera);}
requestAnimationFrame(animate);

// QA can accelerate its own progression; the real UI never calls these helpers.
function prepareHook(){if(phase==='growing')beginHarvest();if(phase==='harvest')harvestCells(Array.from({length:order().targetBoxes},(_,i)=>i),false);if(phase==='delivering')finishDelivery();if(phase==='success')nextOrder();if(['title','won','lost'].includes(phase))start();}
export const gameTest={get ready(){return ready;},start,answerCorrect(){if(!ready)return;prepareHook();setHeight(order().height,false);plant();},answerWrong(){if(!ready)return;prepareHook();setHeight(order().height===12?1:order().height+1,false);plant();},sampleProblems,
 getState:()=>({phase,round:round+1,level:round+1,score,coins,lives,solved,width:order().width,height,targetBoxes:order().targetBoxes,crop:order().crop,tutorial:order().tutorial,attempts,allAttempts,firstTry,firstAttempts,firstAttemptRate:firstAttempts?firstTry/firstAttempts:0,harvested:harvested.size,harvestTotal:order().targetBoxes,growth:farmStage,wins:saved.wins,visibleDecorations:growthGroups.filter(g=>g.visible).length,renderedFrames:frames,inputCount,elapsed:startedAt?(performance.now()-startedAt)/1000:0,duration,assetsLoaded:ready,storageAvailable,result:phase==='won'?'win':phase==='lost'?'loss':null}),
 getLayout(){const w=order().width*CELL,front=BACK+height*CELL;return{wide:innerWidth>=900,stageWidth:innerWidth,mode:innerWidth>=900?'open-farm-and-tools':'portrait-farm',viewport:{...viewport},handle:$('field-handle').getBoundingClientRect().toJSON(),actualFieldCorners:[[-w/2,BACK],[w/2,BACK],[w/2,front],[-w/2,front]].map(([x,z])=>projectWorld(x,.15,z)),crops:phase==='harvest'?cropScreenPoints():[]};},poolSize:POOL.length};

async function load(){try{const loader=new GLTFLoader();await Promise.all(['farmhouse','market-stall','cart','windmill','apple-tree','fence','carrot','carrot-sprout','carrot-young','strawberry','corn','crate'].map(async name=>{templates[name]=(await loader.loadAsync(`./assets/${name}.glb?v=3`)).scene;}));
 const farmhouse=model('farmhouse',3.7,new THREE.Vector3(-5.6,0,-6.7),.1);market=model('market-stall',2.25,new THREE.Vector3(0,0,7.5),Math.PI/2);cart=model('cart',1.08,CART_HOME,-Math.PI/2);crateInstances=makeInstances('crate',144,.12,cart);decorateBuildings(scene,farmhouse,market);
 const mill=model('windmill',3.45,new THREE.Vector3(4,0,-6.9),.2);windRotor=mill.getObjectByName('windmill-rotor');
 for(const [x,z,s,rot]of[[-7.2,-3.7,2.5,.5],[-7.2,.3,2.35,.8],[-7,3.5,2.6,1],[7.5,-3.8,2.65,-.8],[7.7,.5,2.4,.1],[6.8,7.1,2.2,.6]])model('apple-tree',s,new THREE.Vector3(x,0,z),rot);
 for(const [x,z]of[[-9.8,-9],[-7,-10.7],[-3.8,-11.8],[.1,-11.9],[3.8,-11.8],[7.2,-10],[10,-7.2]])model('apple-tree',2.1,new THREE.Vector3(x,0,z),x*.15);
 for(const [x,z,rot]of[[-6.2,-8.4,0],[-4,-8.4,0],[-1.8,-8.4,0],[.4,-8.4,0],[2.6,-8.4,0],[4.8,-8.4,0],[-8.3,-5,Math.PI/2],[-8.3,-2.7,Math.PI/2],[-8.3,-.4,Math.PI/2],[8.5,-5,Math.PI/2],[8.5,-2.7,Math.PI/2],[8.5,-.4,Math.PI/2]])model('fence',.74,new THREE.Vector3(x,0,z),rot);
 for(const key of ['carrot','strawberry','corn'])cropInstances[key]=makeInstances(key,144,CROP_HEIGHT[key]);
 for(const[stage,ratio]of Object.entries(CARROT_STAGE_HEIGHTS))carrotStageInstances[stage]=makeInstances(stage,144,CROP_HEIGHT.carrot*ratio);
 // Three permanent growth additions: flower baskets, new fruit trees, a second market awning.
 for(let i=0;i<3;i++){model('crate',.45,new THREE.Vector3(-1.8+i*.65,0,6.5),.2,growthGroups[0]);for(let j=0;j<4;j++){const flower=new THREE.Mesh(new THREE.IcosahedronGeometry(.13,0),mat(j%2?0xf1c272:0xe79987));flower.position.set(-1.98+i*.65+(j%2)*.3,.43,6.35+Math.floor(j/2)*.3);growthGroups[0].add(flower);}}
 model('apple-tree',2.35,new THREE.Vector3(-4.9,0,5.5),.5,growthGroups[1]);model('apple-tree',2.5,new THREE.Vector3(7.1,0,3.8),-.5,growthGroups[1]);
 model('market-stall',1.5,new THREE.Vector3(-2.6,0,7.7),Math.PI/2,growthGroups[2]);for(let i=0;i<3;i++)model('crate',.42,new THREE.Vector3(-2.4+i*.5,0,6.5),.1,growthGroups[2]);
 for(let i=0;i<72;i++){dummy.position.set((i%8-3.5)*CELL,.077,BACK+(Math.floor(i/8)+.5)*CELL);dummy.rotation.set(0,0,0);dummy.scale.setScalar(1);dummy.updateMatrix();previewTiles.setMatrixAt(i,dummy.matrix);}previewTiles.instanceMatrix.needsUpdate=true;ready=true;setPhase('title');setGuiding(false);updateGrowth();updatePlot();resize();$('start').disabled=false;$('start').textContent='농장으로 가기';$('loading').textContent='기다림 없이, 나만의 작은 농장';
 }catch(error){console.error('햇살 바구니 로딩 실패',error);$('loading').textContent='농장을 불러오지 못했어요. 새로고침해 주세요.';$('start').textContent='불러오기 실패';}}
load();
